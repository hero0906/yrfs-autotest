#!/bin/bash

YRFS=${YRFS:-$(dirname $0)}

if [ ! -f $YRFS/rpc.sh ]; then
	YRFS=$(cd $(dirname $(which $0)); echo $PWD)
fi

. $YRFS/test-framework.sh
RPC_MODE=true init_test_env

# Reset the trap on ERR set by the framework.  Noticing this failure is the
# framework's job.
trap - ERR

log "$HOSTNAME: executing $@"
# Execute the command
"$@"
