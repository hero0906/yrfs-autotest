#!/bin/bash
#
# Run select tests by setting ONLY, or as arguments to the script.
# Skip specific tests by setting EXCEPT.
#
# e.g. ONLY="22 23" or ONLY="`seq 32 39`" or EXCEPT="31"
set -e

ONLY=${ONLY:-"$*"}

echo "test == $ONLY"
# Check Grants after these tests
GRANT_CHECK_LIST="$GRANT_CHECK_LIST 42a 42b 42c 42d 42e 63a 63b 64a 64b 64c 64d"

OSC=${OSC:-"osc"}

CC=${CC:-cc}
CREATETEST=${CREATETEST:-createtest}
LVERIFY=${LVERIFY:-ll_dirstripe_verify}
OPENFILE=${OPENFILE:-${YRFS}/openfile}
OPENUNLINK=${OPENUNLINK:-openunlink}
READS=${READS:-"reads"}
MUNLINK=${MUNLINK:-munlink}
SOCKETSERVER=${SOCKETSERVER:-socketserver}
SOCKETCLIENT=${SOCKETCLIENT:-socketclient}
MEMHOG=${MEMHOG:-memhog}
DIRECTIO=${DIRECTIO:-directio}
ACCEPTOR_PORT=${ACCEPTOR_PORT:-988}
DEF_STRIPE_COUNT=-1
CHECK_GRANT=${CHECK_GRANT:-"yes"}
GRANT_CHECK_LIST=${GRANT_CHECK_LIST:-""}
export PARALLEL=${PARALLEL:-"no"}

TRACE=${TRACE:-""}
YRFS=${YRFS:-$(dirname $0)}
YRFS_TESTS_API_DIR=${YRFS_TESTS_API_DIR:-${YRFS}/clientapi}
. $YRFS/test-framework.sh
init_test_env $@
init_logging


ALWAYS_EXCEPT="$SANITY_EXCEPT "
# bug number for skipped test: LU-9693 LU-6493 LU-9693
ALWAYS_EXCEPT+="36"

proc_regexp="/{proc,sys}/{fs,sys,kernel/debug}/{yrfs,lnet}/"


build_test_filter
FAIL_ON_ERROR=false

cleanup() {
	echo -n "cln.."
	pgrep ll_sa > /dev/null && { echo "There are ll_sa thread not exit!"; exit 20; }
	cleanupall ${FORCE} $* || { echo "FAILed to clean up"; exit 20; }
}
setup() {
	echo -n "mnt.."
        load_modules
	setupall || exit 10
	echo "done"
}

check_swap_layout_no_dom()
{
	local FOLDER=$1
	local SUPP=$(lfs getstripe $FOLDER | grep "pattern:       mdt" | wc -l)
	[ $SUPP -eq 0 ] || skip "layout swap does not support DOM files so far"
}

check_and_setup_yrfs
DIR=${DIR:-$MOUNT}
assert_DIR

MAXFREE=${MAXFREE:-$((300000 * $OSTCOUNT))}

[ -f $DIR/d52a/foo ] && chattr -a $DIR/d52a/foo
[ -f $DIR/d52b/foo ] && chattr -i $DIR/d52b/foo
rm -rf $DIR/[Rdfs][0-9]*

# $RUNAS_ID may get set incorrectly somewhere else
[ $UID -eq 0 -a $RUNAS_ID -eq 0 ] &&
	error "\$RUNAS_ID set to 0, but \$UID is also 0!"

#echo "$RUNAS_ID   $RUNAS_GID    $RUNAS"
#check_runas_id $RUNAS_ID $RUNAS_GID $RUNAS

if [ "${ONLY}" = "MOUNT" ] ; then
	echo "Yrfs is up, please go on"
	exit
fi

echo "preparing for tests involving mounts"
EXT2_DEV=${EXT2_DEV:-$TMP/SANITY.LOOP}
touch $EXT2_DEV
mke2fs -j -F $EXT2_DEV 8000 > /dev/null
echo # add a newline after mke2fs.

umask 077

test_0a() {
	touch $DIR/$tfile
	$CHECKSTAT -t file $DIR/$tfile || error "$tfile is not a file"
	rm $DIR/$tfile
	$CHECKSTAT -a $DIR/$tfile || error "$tfile was not removed"
}
run_test 0a "touch; rm ====================="

test_0b() {
	chmod 0755 $DIR || error "chmod 0755 $DIR failed"
	$CHECKSTAT -p 0755 $DIR || error "$DIR permission is not 0755"
}
run_test 0b "chmod 0755 $DIR ============================="

test_1() {
	test_mkdir $DIR/$tdir
	test_mkdir $DIR/$tdir/d2
	mkdir $DIR/$tdir/d2 && error "we expect EEXIST, but not returned"
	$CHECKSTAT -t dir $DIR/$tdir/d2 || error "$tdir/d2 is not a dir"
	rmdir $DIR/$tdir/d2
	rmdir $DIR/$tdir
	$CHECKSTAT -a $DIR/$tdir || error "$tdir was not removed"
}
run_test 1 "mkdir; remkdir; rmdir"

test_2() {
	test_mkdir $DIR/$tdir
	touch $DIR/$tdir/$tfile || error "touch $tdir/$tfile failed"
	$CHECKSTAT -t file $DIR/$tdir/$tfile || error "$tdir/$tfile not a file"
	rm -r $DIR/$tdir
	$CHECKSTAT -a $DIR/$tdir/$tfile || error "$tdir/$file is not removed"
}
run_test 2 "mkdir; touch; rmdir; check file"

test_3() {
	test_mkdir $DIR/$tdir
	$CHECKSTAT -t dir $DIR/$tdir || error "$tdir is not a directory"
	touch $DIR/$tdir/$tfile
	$CHECKSTAT -t file $DIR/$tdir/$tfile || error "$tdir/$tfile not a file"
	rm -r $DIR/$tdir
	$CHECKSTAT -a $DIR/$tdir || error "$tdir is not removed"
}
run_test 3 "mkdir; touch; rmdir; check dir"

# LU-4471 - failed rmdir on remote directories still removes directory on MDT0
test_4() {
	test_mkdir -i 1 $DIR/$tdir

	touch $DIR/$tdir/$tfile ||
		error "Create file under remote directory failed"

	rmdir $DIR/$tdir &&
		error "Expect error removing in-use dir $DIR/$tdir"

	test -d $DIR/$tdir || error "Remote directory disappeared"

	rm -rf $DIR/$tdir || error "remove remote dir error"
}
run_test 4 "mkdir; touch dir/file; rmdir; checkdir (expect error)"

test_5() {
	test_mkdir $DIR/$tdir
	test_mkdir $DIR/$tdir/d2
	chmod 0707 $DIR/$tdir/d2 || error "chmod 0707 $tdir/d2 failed"
	$CHECKSTAT -t dir -p 0707 $DIR/$tdir/d2 || error "$tdir/d2 not mode 707"
	$CHECKSTAT -t dir $DIR/$tdir/d2 || error "$tdir/d2 is not a directory"
}
run_test 5 "mkdir .../d5 .../d5/d2; chmod .../d5/d2"

test_6a() {
	touch $DIR/$tfile || error "touch $DIR/$tfile failed"
	chmod 0666 $DIR/$tfile || error "chmod 0666 $tfile failed"
	$CHECKSTAT -t file -p 0666 -u \#$UID $DIR/$tfile ||
		error "$tfile does not have perm 0666 or UID $UID"
	$RUNAS chmod 0444 $DIR/$tfile && error "chmod $tfile worked on UID $UID"
	$CHECKSTAT -t file -p 0666 -u \#$UID $DIR/$tfile ||
		error "$tfile should be 0666 and owned by UID $UID"
}
run_test 6a "touch f6a; chmod f6a; $RUNAS chmod f6a (should return error) =="

test_6b() {
	[ $RUNAS_ID -eq $UID ] && skip_env "RUNAS_ID = UID = $UID"

	touch $DIR/$tfile
	chown $RUNAS_ID $DIR/$tfile || error "chown $RUNAS_ID $file failed"
	$CHECKSTAT -t file -u \#$RUNAS_ID $DIR/$tfile ||
		error "$tfile should be owned by UID $RUNAS_ID"
	$RUNAS chown $UID $DIR/$tfile && error "chown $UID $file succeeded"
	$CHECKSTAT -t file -u \#$RUNAS_ID $DIR/$tfile ||
		error "$tfile should be owned by UID $RUNAS_ID"
}
run_test 6b "touch f6c; chown f6c; $RUNAS chown f6c (should return error) =="

test_6c() {
	[ $RUNAS_ID -eq $UID ] && skip_env "RUNAS_ID = UID = $UID"

	touch $DIR/$tfile
	chgrp $RUNAS_ID $DIR/$tfile || error "chgrp $RUNAS_ID $file failed"
	$CHECKSTAT -t file -u \#$UID -g \#$RUNAS_ID $DIR/$tfile ||
		error "$tfile should be owned by GID $UID"
	$RUNAS chgrp $UID $DIR/$tfile && error "chgrp $UID $file succeeded"
	$CHECKSTAT -t file -u \#$UID -g \#$RUNAS_ID $DIR/$tfile ||
		error "$tfile should be owned by UID $UID and GID $RUNAS_ID"
}
run_test 6c "touch+chgrp $tfile; $RUNAS chgrp $tfile (should return error)"

test_6d() { # bug 7331
	[ $RUNAS_ID -eq $UID ] && skip_env "RUNAS_ID = UID = $UID"

	touch $DIR/$tfile || error "touch failed"
	chown $RUNAS_ID:$RUNAS_GID $DIR/$tfile || error "initial chown failed"
	$RUNAS -G$RUNAS_GID chown $RUNAS_ID:0 $DIR/$tfile &&
		error "chown $RUNAS_ID:0 $tfile worked as GID $RUNAS_GID"
	$CHECKSTAT -t file -u \#$RUNAS_ID -g \#$RUNAS_GID $DIR/$tfile ||
		error "$tdir/$tfile should be UID $RUNAS_UID GID $RUNAS_GID"
}
run_test 6d "$RUNAS chown RUNAS_ID.0 .../$tfile (should return error)"

test_7a() {
	test_mkdir $DIR/$tdir
	$MCREATE $DIR/$tdir/$tfile
	chmod 0666 $DIR/$tdir/$tfile
	$CHECKSTAT -t file -p 0666 $DIR/$tdir/$tfile ||
		error "$tdir/$tfile should be mode 0666"
}
run_test 7a "mkdir .../d7; mcreate .../d7/f; chmod .../d7/f ===="

test_7b() {
	if [ ! -d $DIR/$tdir ]; then
		test_mkdir $DIR/$tdir
	fi
	$MCREATE $DIR/$tdir/$tfile
	echo -n foo > $DIR/$tdir/$tfile
	[ "$(cat $DIR/$tdir/$tfile)" = "foo" ] || error "$tdir/$tfile not 'foo'"
	$CHECKSTAT -t file -s 3 $DIR/$tdir/$tfile || error "$tfile size not 3"
}
run_test 7b "mkdir .../d7; mcreate d7/f2; echo foo > d7/f2 ====="

test_8() {
	test_mkdir $DIR/$tdir
	touch $DIR/$tdir/$tfile
	chmod 0666 $DIR/$tdir/$tfile
	$CHECKSTAT -t file -p 0666 $DIR/$tdir/$tfile ||
		error "$tfile mode not 0666"
}
run_test 8 "mkdir .../d8; touch .../d8/f; chmod .../d8/f ======="

test_9() {
	test_mkdir $DIR/$tdir
	test_mkdir $DIR/$tdir/d2
	test_mkdir $DIR/$tdir/d2/d3
	$CHECKSTAT -t dir $DIR/$tdir/d2/d3 || error "$tdir/d2/d3 not a dir"
}
run_test 9 "mkdir .../d9 .../d9/d2 .../d9/d2/d3 ================"

test_10() {
	test_mkdir $DIR/$tdir
	test_mkdir $DIR/$tdir/d2
	touch $DIR/$tdir/d2/$tfile
	$CHECKSTAT -t file $DIR/$tdir/d2/$tfile ||
		error "$tdir/d2/$tfile not a file"
}
run_test 10 "mkdir .../d10 .../d10/d2; touch .../d10/d2/f ======"

test_11() {
	test_mkdir $DIR/$tdir
	test_mkdir $DIR/$tdir/d2
	chmod 0666 $DIR/$tdir/d2
	chmod 0705 $DIR/$tdir/d2
	$CHECKSTAT -t dir -p 0705 $DIR/$tdir/d2 ||
		error "$tdir/d2 mode not 0705"
}
run_test 11 "mkdir .../d11 d11/d2; chmod .../d11/d2 ============"

test_12() {
	test_mkdir $DIR/$tdir
	touch $DIR/$tdir/$tfile
	chmod 0666 $DIR/$tdir/$tfile
	chmod 0654 $DIR/$tdir/$tfile
	$CHECKSTAT -t file -p 0654 $DIR/$tdir/$tfile ||
		error "$tdir/d2 mode not 0654"
}
run_test 12 "touch .../d12/f; chmod .../d12/f .../d12/f ========"

test_13() {
	test_mkdir $DIR/$tdir
	dd if=/dev/zero of=$DIR/$tdir/$tfile count=10
	>  $DIR/$tdir/$tfile
	$CHECKSTAT -t file -s 0 $DIR/$tdir/$tfile ||
		error "$tdir/$tfile size not 0 after truncate"
}
run_test 13 "creat .../d13/f; dd .../d13/f; > .../d13/f ========"

test_14() {
	test_mkdir $DIR/$tdir
	touch $DIR/$tdir/$tfile
	rm $DIR/$tdir/$tfile
	$CHECKSTAT -a $DIR/$tdir/$tfile || error "$tdir/$tfile not removed"
}
run_test 14 "touch .../d14/f; rm .../d14/f; rm .../d14/f ======="

test_15() {
	test_mkdir $DIR/$tdir
	touch $DIR/$tdir/$tfile
	mv $DIR/$tdir/$tfile $DIR/$tdir/${tfile}_2
	$CHECKSTAT -t file $DIR/$tdir/${tfile}_2 ||
		error "$tdir/${tfile_2} not a file after rename"
	rm $DIR/$tdir/${tfile}_2 || error "unlink failed after rename"
}
run_test 15 "touch .../d15/f; mv .../d15/f .../d15/f2 =========="

test_16() {
	test_mkdir $DIR/$tdir
	touch $DIR/$tdir/$tfile
	rm -rf $DIR/$tdir/$tfile
	$CHECKSTAT -a $DIR/$tdir/$tfile || error "$tdir/$tfile not removed"
}
run_test 16 "touch .../d16/f; rm -rf .../d16/f"

test_17a() {
	test_mkdir $DIR/$tdir
	touch $DIR/$tdir/$tfile
	ln -s $DIR/$tdir/$tfile $DIR/$tdir/l-exist
	ls -l $DIR/$tdir
	$CHECKSTAT -l $DIR/$tdir/$tfile $DIR/$tdir/l-exist ||
		error "$tdir/l-exist not a symlink"
	$CHECKSTAT -f -t f $DIR/$tdir/l-exist ||
		error "$tdir/l-exist not referencing a file"
	rm -f $DIR/$tdir/l-exist
	$CHECKSTAT -a $DIR/$tdir/l-exist || error "$tdir/l-exist not removed"
}
run_test 17a "symlinks: create, remove (real)"

test_17b() {
	test_mkdir $DIR/$tdir
	ln -s no-such-file $DIR/$tdir/l-dangle
	ls -l $DIR/$tdir
	$CHECKSTAT -l no-such-file $DIR/$tdir/l-dangle ||
		error "$tdir/l-dangle not referencing no-such-file"
	$CHECKSTAT -fa $DIR/$tdir/l-dangle ||
		error "$tdir/l-dangle not referencing non-existent file"
	rm -f $DIR/$tdir/l-dangle
	$CHECKSTAT -a $DIR/$tdir/l-dangle || error "$tdir/l-dangle not removed"
}
run_test 17b "symlinks: create, remove (dangling)"

test_17c() { # bug 3440 - don't save failed open RPC for replay
	test_mkdir $DIR/$tdir
	ln -s foo $DIR/$tdir/$tfile
	cat $DIR/$tdir/$tfile && error "opened non-existent symlink" || true
}
run_test 17c "symlinks: open dangling (should return error)"

test_17d() {
	test_mkdir $DIR/$tdir
	ln -s foo $DIR/$tdir/$tfile
	touch $DIR/$tdir/$tfile || error "creating to new symlink"
}
run_test 17d "symlinks: create dangling"

test_17e() {
	test_mkdir $DIR/$tdir
	local foo=$DIR/$tdir/$tfile
	ln -s $foo $foo || error "create symlink failed"
	ls -l $foo || error "ls -l failed"
	ls $foo && error "ls not failed" || true
}
run_test 17e "symlinks: create recursive symlink (should return error)"

test_17f() {
	test_mkdir $DIR/$tdir
	ln -s 1234567890/2234567890/3234567890/4234567890 $DIR/$tdir/111
	ln -s 1234567890/2234567890/3234567890/4234567890/5234567890/6234567890 $DIR/$tdir/222
	ln -s 1234567890/2234567890/3234567890/4234567890/5234567890/6234567890/7234567890/8234567890 $DIR/$tdir/333
	ln -s 1234567890/2234567890/3234567890/4234567890/5234567890/6234567890/7234567890/8234567890/9234567890/a234567890/b234567890 $DIR/$tdir/444
	ln -s 1234567890/2234567890/3234567890/4234567890/5234567890/6234567890/7234567890/8234567890/9234567890/a234567890/b234567890/c234567890/d234567890/f234567890 $DIR/$tdir/555
	ln -s 1234567890/2234567890/3234567890/4234567890/5234567890/6234567890/7234567890/8234567890/9234567890/a234567890/b234567890/c234567890/d234567890/f234567890/aaaaaaaaaa/bbbbbbbbbb/cccccccccc/dddddddddd/eeeeeeeeee/ffffffffff/ $DIR/$tdir/666
	ls -l  $DIR/$tdir
}
run_test 17f "symlinks: long and very long symlink name"

# str_repeat(S, N) generate a string that is string S repeated N times
str_repeat() {
	local s=$1
	local n=$2
	local ret=''
	while [ $((n -= 1)) -ge 0 ]; do
		ret=$ret$s
	done
	echo $ret
}

# Long symlinks and LU-2241
test_17g() {
	test_mkdir $DIR/$tdir
	local TESTS="59 60 61 4094"

	for i in $TESTS; do
		local SYMNAME=$(str_repeat 'x' $i)
		ln -s $SYMNAME $DIR/$tdir/f$i || error "failed $i-char symlink"
		readlink $DIR/$tdir/f$i	|| error "failed $i-char readlink"
	done
}
run_test 17g "symlinks: really long symlink name and inode boundaries"

test_17h() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"
	[[ -z "$(which rsync 2>/dev/null)" ]] &&
		skip "no rsync command"
	rsync --help | grep -q xattr ||
		skip_env "$(rsync --version | head -n1) does not support xattrs"
	test_mkdir $DIR/$tdir
	test_mkdir $DIR/$tdir.new
	touch $DIR/$tdir/$tfile
	ln -s $DIR/$tdir/$tfile $DIR/$tdir/$tfile.lnk
	rsync -av -X $DIR/$tdir/ $DIR/$tdir.new ||
		error "rsync failed with xattrs enabled"
}
run_test 17h "symlinks: rsync with xattrs enabled"

test_17i() {
	[[ -z "$(which getfattr 2>/dev/null)" ]] &&
		skip "no getfattr command"

	test_mkdir $DIR/$tdir
	touch $DIR/$tdir/$tfile
	ln -s $DIR/$tdir/$tfile $DIR/$tdir/$tfile.lnk
	for path in "$DIR/$tdir" "$DIR/$tdir/$tfile" "$DIR/$tdir/$tfile.lnk"; do
		# -h to not follow symlinks. -m '' to list all the xattrs.
		# grep to remove first line: '# file: $path'.
		for xattr in `getfattr -hm '' $path 2>/dev/null | grep -v '^#'`;
		do
			lgetxattr_size_check $path $xattr ||
				error "lgetxattr_size_check $path $xattr failed"
		done
	done
}
run_test 17i "Ensure lgetxattr's returned xattr size is consistent"

test_18() {
	touch $DIR/$tfile || error "Failed to touch $DIR/$tfile: $?"
	ls $DIR || error "Failed to ls $DIR: $?"
}
run_test 18 "touch .../f ; ls ... =============================="

test_19a() {
	touch $DIR/$tfile
	ls -l $DIR
	rm $DIR/$tfile
	$CHECKSTAT -a $DIR/$tfile || error "$tfile was not removed"
}
run_test 19a "touch .../f19 ; ls -l ... ; rm .../f19 ==========="

test_19b() {
	ls -l $DIR/$tfile && error "ls -l $tfile failed"|| true
}
run_test 19b "ls -l .../f19 (should return error) =============="

test_19c() {
	[ $RUNAS_ID -eq $UID ] &&
		skip_env "RUNAS_ID = UID = $UID -- skipping"

	$RUNAS touch $DIR/$tfile && error "create non-root file failed" || true
}
run_test 19c "$RUNAS touch .../f19 (should return error) =="

test_19d() {
	cat $DIR/f19 && error || true
}
run_test 19d "cat .../f19 (should return error) =============="

test_20() {
	touch $DIR/$tfile
	rm $DIR/$tfile
	touch $DIR/$tfile
	rm $DIR/$tfile
	touch $DIR/$tfile
	rm $DIR/$tfile
	$CHECKSTAT -a $DIR/$tfile || error "$tfile was not removed"
}
run_test 20 "touch .../f ; ls -l ..."

test_21() {
	test_mkdir $DIR/$tdir
	[ -f $DIR/$tdir/dangle ] && rm -f $DIR/$tdir/dangle
	ln -s dangle $DIR/$tdir/link
	echo foo >> $DIR/$tdir/link
	cat $DIR/$tdir/dangle
	$CHECKSTAT -t link $DIR/$tdir/link || error "$tdir/link not a link"
	$CHECKSTAT -f -t file $DIR/$tdir/link ||
		error "$tdir/link not linked to a file"
}
run_test 21 "write to dangling link"

test_22() {
	local wdir=$DIR/$tdir
	test_mkdir $wdir

	chown $RUNAS_ID:$RUNAS_GID $wdir
	(cd $wdir || error "cd $wdir failed";
		${YRFS}/${RUNAS} tar cf - /etc/hosts /etc/sysconfig/network |
		${YRFS}/${RUNAS} tar xf -)
	ls -lR $wdir/etc || error "ls -lR $wdir/etc failed"
	$CHECKSTAT -t dir $wdir/etc || error "checkstat -t dir failed"
	$CHECKSTAT -u \#$RUNAS_ID -g \#$RUNAS_GID $wdir/etc ||
		error "checkstat -u failed"
}
run_test 22 "unpack tar archive as non-root user"

# was test_23
test_23a() {
	test_mkdir $DIR/$tdir
	local file=$DIR/$tdir/$tfile

	openfile -f O_CREAT:O_EXCL $file || error "$file create failed"
	openfile -f O_CREAT:O_EXCL $file &&
		error "$file recreate succeeded" || true
}
run_test 23a "O_CREAT|O_EXCL in subdir"

test_23b() { # bug 18988
	test_mkdir $DIR/$tdir
	local file=$DIR/$tdir/$tfile

	rm -f $file
	echo foo > $file || error "write filed"
	echo bar >> $file || error "append filed"
	$CHECKSTAT -s 8 $file || error "wrong size"
	rm $file
}
run_test 23b "O_APPEND check"

# LU-9409, size with O_APPEND and tiny writes
test_23c() {
	local file=$DIR/$tfile

	# single dd
	dd conv=notrunc oflag=append if=/dev/zero of=$file bs=8 count=800
	$CHECKSTAT -s 6400 $file || error "wrong size, expected 6400"
	rm -f $file

	# racing tiny writes
	dd conv=notrunc oflag=append if=/dev/zero of=$file bs=8 count=800 &
	dd conv=notrunc oflag=append if=/dev/zero of=$file bs=8 count=800 &
	wait
	$CHECKSTAT -s 12800 $file || error "wrong size, expected 12800"
	rm -f $file

	#racing tiny & normal writes
	dd conv=notrunc oflag=append if=/dev/zero of=$file bs=4096 count=4 &
	dd conv=notrunc oflag=append if=/dev/zero of=$file bs=8 count=100 &
	wait
	$CHECKSTAT -s 17184 $file || error "wrong size, expected 17184"
	rm -f $file

	#racing tiny & normal writes 2, ugly numbers
	dd conv=notrunc oflag=append if=/dev/zero of=$file bs=4099 count=11 &
	dd conv=notrunc oflag=append if=/dev/zero of=$file bs=17 count=173 &
	wait
	$CHECKSTAT -s 48030 $file || error "wrong size, expected 48030"
	rm -f $file
}
run_test 23c "O_APPEND size checks for tiny writes"

test_23d() {
	local file=$DIR/$tfile
	local offset

	echo CentaurHauls > $file
	offset=$($MULTIOP $file oO_WRONLY:O_APPEND:w13Zp)
	if ((offset != 26)); then
		error "wrong offset, expected 26, got '$offset'"
	fi
}
run_test 23d "file offset is correct after appending writes"

# rename sanity
test_24a() {
	echo '-- same directory rename'
	test_mkdir $DIR/$tdir
	touch $DIR/$tdir/$tfile.1
	mv $DIR/$tdir/$tfile.1 $DIR/$tdir/$tfile.2
	$CHECKSTAT -t file $DIR/$tdir/$tfile.2 || error "$tfile.2 not a file"
}
run_test 24a "rename file to non-existent target"

test_24b() {
	test_mkdir $DIR/$tdir
	touch $DIR/$tdir/$tfile.{1,2}
	mv $DIR/$tdir/$tfile.1 $DIR/$tdir/$tfile.2
	$CHECKSTAT -a $DIR/$tdir/$tfile.1 || error "$tfile.1 exists"
	$CHECKSTAT -t file $DIR/$tdir/$tfile.2 || error "$tfile.2 not a file"
}
run_test 24b "rename file to existing target"

test_24c() {
	test_mkdir $DIR/$tdir
	test_mkdir $DIR/$tdir/d$testnum.1
	mv $DIR/$tdir/d$testnum.1 $DIR/$tdir/d$testnum.2
	$CHECKSTAT -a $DIR/$tdir/d$testnum.1 || error "d$testnum.1 exists"
	$CHECKSTAT -t dir $DIR/$tdir/d$testnum.2 || error "d$testnum.2 not dir"
}
run_test 24c "rename directory to non-existent target"

test_24d() {
	test_mkdir -c1 $DIR/$tdir
	test_mkdir -c1 $DIR/$tdir/d$testnum.1
	test_mkdir -c1 $DIR/$tdir/d$testnum.2
	mrename $DIR/$tdir/d$testnum.1 $DIR/$tdir/d$testnum.2
	$CHECKSTAT -a $DIR/$tdir/d$testnum.1 || error "d$testnum.1 exists"
	$CHECKSTAT -t dir $DIR/$tdir/d$testnum.2 || error "d$testnum.2 not dir"
}
run_test 24d "rename directory to existing target"

test_24e() {
	echo '-- cross directory renames --'
	test_mkdir $DIR/R5a
	test_mkdir $DIR/R5b
	touch $DIR/R5a/f
	mv $DIR/R5a/f $DIR/R5b/g
	$CHECKSTAT -a $DIR/R5a/f || error "$DIR/R5a/f exists"
	$CHECKSTAT -t file $DIR/R5b/g || error "$DIR/R5b/g not file type"
}
run_test 24e "touch .../R5a/f; rename .../R5a/f .../R5b/g ======"

test_24f() {
	test_mkdir $DIR/R6a
	test_mkdir $DIR/R6b
	touch $DIR/R6a/f $DIR/R6b/g
	mv $DIR/R6a/f $DIR/R6b/g
	$CHECKSTAT -a $DIR/R6a/f || error "$DIR/R6a/f exists"
	$CHECKSTAT -t file $DIR/R6b/g || error "$DIR/R6b/g not file type"
}
run_test 24f "touch .../R6a/f R6b/g; mv .../R6a/f .../R6b/g ===="

test_24g() {
	test_mkdir $DIR/R7a
	test_mkdir $DIR/R7b
	test_mkdir $DIR/R7a/d
	mv $DIR/R7a/d $DIR/R7b/e
	$CHECKSTAT -a $DIR/R7a/d || error "$DIR/R7a/d exists"
	$CHECKSTAT -t dir $DIR/R7b/e || error "$DIR/R7b/e not dir type"
}
run_test 24g "mkdir .../R7{a,b}/d; mv .../R7a/d .../R7b/e ======"

test_24h() {
	test_mkdir -c1 $DIR/R8a
	test_mkdir -c1 $DIR/R8b
	test_mkdir -c1 $DIR/R8a/d
	test_mkdir -c1 $DIR/R8b/e
	mrename $DIR/R8a/d $DIR/R8b/e
	$CHECKSTAT -a $DIR/R8a/d || error "$DIR/R8a/d exists"
	$CHECKSTAT -t dir $DIR/R8b/e || error "$DIR/R8b/e not dir type"
}
run_test 24h "mkdir .../R8{a,b}/{d,e}; rename .../R8a/d .../R8b/e"

test_24i() {
	echo "-- rename error cases"
	test_mkdir $DIR/R9
	test_mkdir $DIR/R9/a
	touch $DIR/R9/f
	mrename $DIR/R9/f $DIR/R9/a
	$CHECKSTAT -t file $DIR/R9/f || error "$DIR/R9/f not file type"
	$CHECKSTAT -t dir  $DIR/R9/a || error "$DIR/R9/a not dir type"
	$CHECKSTAT -a $DIR/R9/a/f || error "$DIR/R9/a/f exists"
}
run_test 24i "rename file to dir error: touch f ; mkdir a ; rename f a"

test_24j() {
	test_mkdir $DIR/R10
	mrename $DIR/R10/f $DIR/R10/g
	$CHECKSTAT -t dir $DIR/R10 || error "$DIR/R10 not dir type"
	$CHECKSTAT -a $DIR/R10/f || error "$DIR/R10/f exists"
	$CHECKSTAT -a $DIR/R10/g || error "$DIR/R10/g exists"
}
run_test 24j "source does not exist ============================"

test_24k() {
	test_mkdir $DIR/R11a
	test_mkdir $DIR/R11a/d
	touch $DIR/R11a/f
	mv $DIR/R11a/f $DIR/R11a/d
	$CHECKSTAT -a $DIR/R11a/f || error "$DIR/R11a/f exists"
	$CHECKSTAT -t file $DIR/R11a/d/f || error "$DIR/R11a/d/f not file type"
}
run_test 24k "touch .../R11a/f; mv .../R11a/f .../R11a/d ======="

test_24l() {
    f="$DIR/f24n"
    # this stats the old file after it was renamed, so it should fail
    touch ${f}
    $CHECKSTAT ${f} || error "${f} missing"
    mv ${f} ${f}.rename
    $CHECKSTAT ${f}.rename || error "${f}.rename missing"
    $CHECKSTAT -a ${f} || error "${f} exists"
}
run_test 24l "Statting the old file after renaming (Posix rename 2)"

test_24m() {
	test_mkdir $DIR/$tdir
	rename_many -s random -v -n 10 $DIR/$tdir
}
run_test 24m "rename of files during htree split"

test_24n() {
	test_mkdir $DIR/R12a
	test_mkdir $DIR/R12b
	DIRINO=`ls -lid $DIR/R12a | awk '{ print $1 }'`
	mrename $DIR/R12a $DIR/R12b
	$CHECKSTAT -a $DIR/R12a || error "$DIR/R12a exists"
	$CHECKSTAT -t dir $DIR/R12b || error "$DIR/R12b not dir type"
	DIRINO2=`ls -lid $DIR/R12b | awk '{ print $1 }'`
	[ "$DIRINO" = "$DIRINO2" ] || error "R12a $DIRINO != R12b $DIRINO2"
}
run_test 24n "mkdir .../R12{a,b}; rename .../R12a .../R12b"

test_24o() { #bug 3789
	test_mkdir $DIR/R14a
	test_mkdir $DIR/R14a/b
	mrename $DIR/R14a $DIR/R14a/b && error "rename to subdir worked!"
	$CHECKSTAT -t dir $DIR/R14a || error "$DIR/R14a missing"
	$CHECKSTAT -t dir $DIR/R14a/b || error "$DIR/R14a/b missing"
}
run_test 24o "mkdir .../R14a/b; rename .../R14a .../R14a/b ====="

test_24p() {
	test_mkdir $DIR/R15a
	test_mkdir $DIR/R15a/b
	test_mkdir $DIR/R15a/b/c
	mrename $DIR/R15a $DIR/R15a/b/c && error "rename to sub-subdir worked!"
	$CHECKSTAT -t dir $DIR/R15a || error "$DIR/R15a missing"
	$CHECKSTAT -t dir $DIR/R15a/b/c || error "$DIR/R15a/b/c missing"
}
run_test 24p "mkdir .../R15a/b/c; rename .../R15a .../R15a/b/c ="

test_24q() {
	test_mkdir $DIR/R16a
	test_mkdir $DIR/R16a/b
	test_mkdir $DIR/R16a/b/c
	mrename $DIR/R16a/b/c $DIR/R16a && error "rename to sub-subdir worked!"
	$CHECKSTAT -t dir $DIR/R16a || error "$DIR/R16a missing"
	$CHECKSTAT -t dir $DIR/R16a/b/c || error "$DIR/R16a/b/c missing"
}
run_test 24q "mkdir .../R16a/b/c; rename .../R16a/b/c .../R16a ="

test_24r() { # bug21506
        SZ1=234852
        dd if=/dev/zero of=$DIR/$tfile bs=1M count=1 seek=4096 || return 1
        dd if=/dev/zero bs=$SZ1 count=1 >> $DIR/$tfile || return 2
        dd if=$DIR/$tfile of=$DIR/${tfile}_left bs=1M skip=4097 || return 3
        SZ2=`ls -l $DIR/${tfile}_left | awk '{print $5}'`
	[[ "$SZ1" -eq "$SZ2" ]] ||
                error "Error reading at the end of the file $tfile"
}
run_test 24r "Reading a file larger than 4Gb"

test_24s() {
	f="$DIR/f24s"
	$MULTIOP $f OcNs || error "rename of ${f} to itself failed"
}
run_test 24s "Renaming a file to itself ========================"

test_24t() {
	f="$DIR/f24t"
	$MULTIOP $f OcLN ${f}2 ${f}2 || error "link ${f}2 ${f}2 failed"
	# on ext3 this does not remove either the source or target files
	# though the "expected" operation would be to remove the source
	$CHECKSTAT -t file ${f} || error "${f} missing"
	$CHECKSTAT -t file ${f}2 || error "${f}2 missing"
}
run_test 24t "Renaming a file to a hard link to itself ========="

test_25a() {
	echo '== symlink sanity ============================================='

	test_mkdir $DIR/d25
	ln -s d25 $DIR/s25
	touch $DIR/s25/foo ||
		error "File creation in symlinked directory failed"
}
run_test 25a "create file in symlinked directory ==============="

test_25b() {
	[ ! -d $DIR/d25 ] && test_25a
	$CHECKSTAT -t file $DIR/s25/foo || error "$DIR/s25/foo not file type"
}
run_test 25b "lookup file in symlinked directory ==============="

test_26a() {
	test_mkdir $DIR/d26
	test_mkdir $DIR/d26/d26-2
	ln -s d26/d26-2 $DIR/s26
	touch $DIR/s26/foo || error "File creation failed"
}
run_test 26a "multiple component symlink ======================="

test_26b() {
	test_mkdir -p $DIR/$tdir/d26-2
	ln -s $tdir/d26-2/foo $DIR/s26-2
	touch $DIR/s26-2 || error "File creation failed"
}
run_test 26b "multiple component symlink at end of lookup ======"

test_26c() {
	test_mkdir $DIR/d26.2
	touch $DIR/d26.2/foo
	ln -s d26.2 $DIR/s26.2-1
	ln -s s26.2-1 $DIR/s26.2-2
	ln -s s26.2-2 $DIR/s26.2-3
	chmod 0666 $DIR/s26.2-3/foo
}
run_test 26c "chain of symlinks"

# recursive symlinks (bug 439)
test_26d() {
	ln -s d26-3/foo $DIR/d26-3
}
run_test 26d "create multiple component recursive symlink"

test_26e() {
	[ ! -h $DIR/d26-3 ] && test_26d
	rm $DIR/d26-3
}
run_test 26e "unlink multiple component recursive symlink"

# recursive symlinks (bug 7022)
test_26f() {
	test_mkdir $DIR/$tdir
	test_mkdir $DIR/$tdir/$tfile
	cd $DIR/$tdir/$tfile           || error "cd $DIR/$tdir/$tfile failed"
	test_mkdir -p lndir/bar1
	test_mkdir $DIR/$tdir/$tfile/$tfile
	cd $tfile                || error "cd $tfile failed"
	ln -s .. dotdot          || error "ln dotdot failed"
	ln -s dotdot/lndir lndir || error "ln lndir failed"
	cd $DIR/$tdir                 || error "cd $DIR/$tdir failed"
	output=`ls $tfile/$tfile/lndir/bar1`
	[ "$output" = bar1 ] && error "unexpected output"
	rm -r $tfile             || error "rm $tfile failed"
	cd $YRFS         || error "cd $YRFS failed"
	$CHECKSTAT -a $DIR/$tdir/$tfile || error "$tfile not gone"
}
run_test 26f "rm -r of a directory which has recursive symlink"
	
# createtest also checks that device nodes are created and
# then visible correctly (#2091)
test_28() { # bug 2091
	test_mkdir $DIR/d28
	$CREATETEST $DIR/d28/ct || error "createtest failed"
}
run_test 28 "create/mknod/mkdir with bad file types ============"

test_30a() { # was test_30
	cp $(which ls) $DIR || cp /bin/ls $DIR
	$DIR/ls / || error "Can't execute binary from yrfs"
	rm $DIR/ls
}
run_test 30a "execute binary from Yrfs (execve) =============="

test_30b() {
	cp `which ls` $DIR || cp /bin/ls $DIR
	chmod go+rx $DIR/ls
	$RUNAS $DIR/ls / || error "Can't execute binary from yrfs as non-root"
	rm $DIR/ls
}
run_test 30b "execute binary from Yrfs as non-root ==========="

test_30c() { # b=22376
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	cp $(which ls) $DIR || cp /bin/ls $DIR
	chmod a-rw $DIR/ls
	#cancel_lru_locks mdc
	#cancel_lru_locks osc
	$RUNAS $DIR/ls / || error "Can't execute binary from yrfs"
	rm -f $DIR/ls
}
run_test 30c "execute binary from yrfs without read perms ===="

test_30d() {
	cp $(which dd) $DIR || error "failed to copy dd to $DIR/dd"

	for i in {1..10}; do
		$DIR/dd bs=1M count=128 if=/dev/zero of=$DIR/$tfile &
		local PID=$!
		sleep 1
		#$LCTL set_param ldlm.namespaces.*MDT*.lru_size=clear
		wait $PID || error "executing dd from yrfs failed"
		rm -f $DIR/$tfile
	done

	rm -f $DIR/dd
}
run_test 30d "execute binary from yrfs while clear locks"

test_31a() {
	$OPENUNLINK $DIR/f31 $DIR/f31 || error "openunlink failed"
	$CHECKSTAT -a $DIR/f31 || error "$DIR/f31 exists"
}
run_test 31a "open-unlink file =================================="

test_31b() {
	opendirunlink $DIR/d31d $DIR/d31d || error "opendirunlink failed"
	$CHECKSTAT -a $DIR/d31d || error "$DIR/d31d exists"
}
run_test 31b "remove of open directory ========================="

test_31c() { # bug 2904
	openfilleddirunlink $DIR/d31e || error "openfilleddirunlink failed"
}
run_test 31c "remove of open non-empty directory ==============="

test_31d() {
	touch $DIR/$tfile || error "cannot create '$DIR/$tfile'"
	nlink=$(stat --format=%h $DIR/$tfile)
	[ ${nlink:--1} -eq 1 ] || error "nlink is $nlink, expected 1"
	local fd=$(free_fd)
	local cmd="exec $fd<$DIR/$tfile"
	eval $cmd
	cmd="exec $fd<&-"
	trap "eval $cmd" EXIT
	nlink=$(stat --dereference --format=%h /proc/self/fd/$fd)
	[ ${nlink:--1} -eq 1 ] || error "nlink is $nlink, expected 1"
	rm $DIR/$tfile || error "cannot remove '$DIR/$tfile'"
	nlink=$(stat --dereference --format=%h /proc/self/fd/$fd)
	[ ${nlink:--1} -eq 0 ] || error "nlink is $nlink, expected 0"
	eval $cmd
}
run_test 31d "check link count of unlinked file"

link_one() {
	local tempfile=$(mktemp $1_XXXXXX)
	mlink $tempfile $1 2> /dev/null &&
		echo "$BASHPID: link $tempfile to $1 succeeded"
	munlink $tempfile
}

test_31e() { # LU-2901
	test_mkdir $DIR/$tdir
	for LOOP in $(seq 100); do
		rm -f $DIR/$tdir/$tfile*
		for THREAD in $(seq 8); do
			link_one $DIR/$tdir/$tfile.$LOOP &
		done
		wait
		local LINKS=$(ls -1 $DIR/$tdir | grep -c $tfile.$LOOP)
		[[ $LINKS -gt 1 ]] && ls $DIR/$tdir &&
			error "$LINKS duplicate links to $tfile.$LOOP" &&
			break || true
	done
}
run_test 31e "duplicate hard links with same filename"

# Does not support creating hard links across directories
# 31g 31h 31i 31j 31k 31m
test_31g() {
	echo "-- cross directory link --"
	test_mkdir -c1 $DIR/${tdir}ga
	test_mkdir -c1 $DIR/${tdir}gb
	touch $DIR/${tdir}ga/f
	ln $DIR/${tdir}ga/f $DIR/${tdir}gb/g
	$CHECKSTAT -t file $DIR/${tdir}ga/f || error "source"
	[ `stat -c%h $DIR/${tdir}ga/f` == '2' ] || error "source nlink"
	$CHECKSTAT -t file $DIR/${tdir}gb/g || error "target"
	[ `stat -c%h $DIR/${tdir}gb/g` == '2' ] || error "target nlink"
}
#run_test 31g "cross directory link==============="

test_31h() {
	echo "-- cross directory link --"
	test_mkdir -c1 $DIR/${tdir}
	test_mkdir -c1 $DIR/${tdir}/dir
	touch $DIR/${tdir}/f
	ln $DIR/${tdir}/f $DIR/${tdir}/dir/g
	$CHECKSTAT -t file $DIR/${tdir}/f || error "source"
	[ `stat -c%h $DIR/${tdir}/f` == '2' ] || error "source nlink"
	$CHECKSTAT -t file $DIR/${tdir}/dir/g || error "target"
	[ `stat -c%h $DIR/${tdir}/dir/g` == '2' ] || error "target nlink"
}
#run_test 31h "cross directory link under child==============="

test_31i() {
	echo "-- cross directory link --"
	test_mkdir -c1 $DIR/$tdir
	test_mkdir -c1 $DIR/$tdir/dir
	touch $DIR/$tdir/dir/f
	ln $DIR/$tdir/dir/f $DIR/$tdir/g
	$CHECKSTAT -t file $DIR/$tdir/dir/f || error "source"
	[ `stat -c%h $DIR/$tdir/dir/f` == '2' ] || error "source nlink"
	$CHECKSTAT -t file $DIR/$tdir/g || error "target"
	[ `stat -c%h $DIR/$tdir/g` == '2' ] || error "target nlink"
}
#run_test 31i "cross directory link under parent==============="

test_31j() {
	test_mkdir -c1 -p $DIR/$tdir
	test_mkdir -c1 -p $DIR/$tdir/dir1
	ln $DIR/$tdir/dir1 $DIR/$tdir/dir2 && error "ln for dir"
	link $DIR/$tdir/dir1 $DIR/$tdir/dir3 && error "link for dir"
	mlink $DIR/$tdir/dir1 $DIR/$tdir/dir4 && error "mlink for dir"
	mlink $DIR/$tdir/dir1 $DIR/$tdir/dir1 && error "mlink to the same dir"
	return 0
}
#run_test 31j "link for directory==============="

test_31k() {
        test_mkdir -c1 -p $DIR/$tdir
        touch $DIR/$tdir/s
        touch $DIR/$tdir/exist
        mlink $DIR/$tdir/s $DIR/$tdir/t || error "mlink"
        mlink $DIR/$tdir/s $DIR/$tdir/exist && error "mlink to exist file"
        mlink $DIR/$tdir/s $DIR/$tdir/s && error "mlink to the same file"
        mlink $DIR/$tdir/s $DIR/$tdir && error "mlink to parent dir"
        mlink $DIR/$tdir $DIR/$tdir/s && error "mlink parent dir to target"
        mlink $DIR/$tdir/not-exist $DIR/$tdir/foo && error "mlink non-existing to new"
        mlink $DIR/$tdir/not-exist $DIR/$tdir/s && error "mlink non-existing to exist"
	return 0
}
#run_test 31k "link to file: the same, non-existing, dir==============="

test_31m() {
        mkdir $DIR/d31m
        touch $DIR/d31m/s
        mkdir $DIR/d31m2
        touch $DIR/d31m2/exist
        mlink $DIR/d31m/s $DIR/d31m2/t || error "mlink"
        mlink $DIR/d31m/s $DIR/d31m2/exist && error "mlink to exist file"
        mlink $DIR/d31m/s $DIR/d31m2 && error "mlink to parent dir"
        mlink $DIR/d31m2 $DIR/d31m/s && error "mlink parent dir to target"
        mlink $DIR/d31m/not-exist $DIR/d31m2/foo && error "mlink non-existing to new"
        mlink $DIR/d31m/not-exist $DIR/d31m2/s && error "mlink non-existing to exist"
	return 0
}
#run_test 31m "link to file: the same, non-existing, dir==============="

multiop_bg_pause() {
	MULTIOP_PROG=${MULTIOP_PROG:-$MULTIOP}
	FILE=$1
	ARGS=$2

	TMPPIPE=/tmp/multiop_open_wait_pipe.$$
	mkfifo $TMPPIPE

	echo "$MULTIOP_PROG $FILE v$ARGS"
	$MULTIOP_PROG $FILE v$ARGS > $TMPPIPE &

	echo "TMPPIPE=${TMPPIPE}"
	read -t 60 multiop_output < $TMPPIPE
	if [ $? -ne 0 ]; then
		rm -f $TMPPIPE
		return 1
	fi
	rm -f $TMPPIPE
	if [ "$multiop_output" != "PAUSING" ]; then
		echo "Incorrect multiop output: $multiop_output"
		kill -9 $PID
		return 1
	fi

	return 0
}

test_31n() {
	touch $DIR/f31 || error "touch $DIR/f31 failed"
	ln $DIR/f31 $DIR/f31n || error "ln failed"
	$MULTIOP $DIR/f31n Ouc || error "multiop failed"
	$CHECKSTAT -t file $DIR/f31 || error "$DIR/f31 not file type"
}
run_test 31n "unlink file with multiple links while open ======="

test_31o() {
	touch $DIR/f31 || error "touch $DIR/f31 failed"
	ln $DIR/f31 $DIR/f31o || error "ln failed"
	multiop_bg_pause $DIR/f31 O_uc ||
		error "multiop_bg_pause for $DIR/f31 failed"
	MULTIPID=$!
	$MULTIOP $DIR/f31o Ouc
	kill -USR1 $MULTIPID
	wait $MULTIPID
}
run_test 31o "open-unlink file with multiple links ============="

cleanup_test32_mount() {
	local rc=0
	trap 0
	local loopdev=$(losetup -a | grep $EXT2_DEV | sed -ne 's/:.*$//p')
	$UMOUNT $DIR/$tdir/ext2-mountpoint || rc=$?
	losetup -d $loopdev || true
	rm -rf $DIR/$tdir
	return $rc
}

test_32a() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	echo "== more mountpoints and symlinks ================="
	[ -e $DIR/$tdir ] && rm -fr $DIR/$tdir
	trap cleanup_test32_mount EXIT
	test_mkdir -p $DIR/$tdir/ext2-mountpoint
	mount -t ext2 -o loop $EXT2_DEV $DIR/$tdir/ext2-mountpoint ||
		error "mount failed for $EXT2_DEV $DIR/$tdir/ext2-mountpoint"
	$CHECKSTAT -t dir $DIR/$tdir/ext2-mountpoint/.. ||
		error "$DIR/$tdir/ext2-mountpoint/.. not dir type"
	cleanup_test32_mount
}
run_test 32a "stat d32a/ext2-mountpoint/.. ====================="

test_32b() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	[ -e $DIR/$tdir ] && rm -fr $DIR/$tdir
	trap cleanup_test32_mount EXIT
	test_mkdir -p $DIR/$tdir/ext2-mountpoint
	mount -t ext2 -o loop $EXT2_DEV $DIR/$tdir/ext2-mountpoint ||
		error "mount failed for $EXT2_DEV $DIR/$tdir/ext2-mountpoint"
	ls -al $DIR/$tdir/ext2-mountpoint/.. ||
		error "Can't list $DIR/$tdir/ext2-mountpoint/.."
	cleanup_test32_mount
}
run_test 32b "open d32b/ext2-mountpoint/.. ====================="

test_32c() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	[ -e $DIR/$tdir ] && rm -fr $DIR/$tdir
	trap cleanup_test32_mount EXIT
	test_mkdir -p $DIR/$tdir/ext2-mountpoint
	mount -t ext2 -o loop $EXT2_DEV $DIR/$tdir/ext2-mountpoint ||
		error "mount failed for $EXT2_DEV $DIR/$tdir/ext2-mountpoint"
	test_mkdir -p $DIR/$tdir/d2/test_dir
	$CHECKSTAT -t dir $DIR/$tdir/ext2-mountpoint/../d2/test_dir ||
		error "$DIR/$tdir/ext2-mountpoint/../d2/test_dir not dir type"
	cleanup_test32_mount
}
run_test 32c "stat d32c/ext2-mountpoint/../d2/test_dir ========="

test_32d() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	[ -e $DIR/$tdir ] && rm -fr $DIR/$tdir
	trap cleanup_test32_mount EXIT
	test_mkdir -p $DIR/$tdir/ext2-mountpoint
	mount -t ext2 -o loop $EXT2_DEV $DIR/$tdir/ext2-mountpoint ||
		error "mount failed for $EXT2_DEV $DIR/$tdir/ext2-mountpoint"
	test_mkdir -p $DIR/$tdir/d2/test_dir
	ls -al $DIR/$tdir/ext2-mountpoint/../d2/test_dir ||
		error "Can't list $DIR/$tdir/ext2-mountpoint/../d2/test_dir"
	cleanup_test32_mount
}
run_test 32d "open d32d/ext2-mountpoint/../d2/test_dir"

test_32e() {
	rm -fr $DIR/$tdir
	test_mkdir -p $DIR/$tdir/tmp
	local tmp_dir=$DIR/$tdir/tmp
	ln -s $DIR/$tdir $tmp_dir/symlink11
	ln -s $tmp_dir/symlink11 $tmp_dir/../symlink01
	$CHECKSTAT -t link $DIR/$tdir/tmp/symlink11 || error "symlink11 bad"
	$CHECKSTAT -t link $DIR/$tdir/symlink01 || error "symlink01 bad"
}
run_test 32e "stat d32e/symlink->tmp/symlink->yrfs-subdir"

test_32f() {
	rm -fr $DIR/$tdir
	test_mkdir -p $DIR/$tdir/tmp
	local tmp_dir=$DIR/$tdir/tmp
	ln -s $DIR/$tdir $tmp_dir/symlink11
	ln -s $tmp_dir/symlink11 $tmp_dir/../symlink01
	ls $DIR/$tdir/tmp/symlink11  || error "symlink11 bad"
	ls $DIR/$tdir/symlink01 || error "symlink01 bad"
}
run_test 32f "open d32f/symlink->tmp/symlink->yrfs-subdir"

test_32g() {
	local tmp_dir=$DIR/$tdir/tmp
	test_mkdir -p $tmp_dir
	test_mkdir $DIR/${tdir}2
	ln -s $DIR/${tdir}2 $tmp_dir/symlink12
	ln -s $tmp_dir/symlink12 $tmp_dir/../symlink02
	$CHECKSTAT -t link $tmp_dir/symlink12 || error "symlink12 not a link"
	$CHECKSTAT -t link $DIR/$tdir/symlink02 || error "symlink02 not a link"
	$CHECKSTAT -t dir -f $tmp_dir/symlink12 || error "symlink12 not a dir"
	$CHECKSTAT -t dir -f $DIR/$tdir/symlink02 || error "symlink12 not a dir"
}
run_test 32g "stat d32g/symlink->tmp/symlink->yrfs-subdir/${tdir}2"

test_32h() {
	rm -fr $DIR/$tdir $DIR/${tdir}2
	tmp_dir=$DIR/$tdir/tmp
	test_mkdir -p $tmp_dir
	test_mkdir $DIR/${tdir}2
	ln -s $DIR/${tdir}2 $tmp_dir/symlink12
	ln -s $tmp_dir/symlink12 $tmp_dir/../symlink02
	ls $tmp_dir/symlink12 || error "listing symlink12"
	ls $DIR/$tdir/symlink02  || error "listing symlink02"
}
run_test 32h "open d32h/symlink->tmp/symlink->yrfs-subdir/${tdir}2"

test_32i() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	[ -e $DIR/$tdir ] && rm -fr $DIR/$tdir
	trap cleanup_test32_mount EXIT
	test_mkdir -p $DIR/$tdir/ext2-mountpoint
	mount -t ext2 -o loop $EXT2_DEV $DIR/$tdir/ext2-mountpoint ||
		error "mount failed for $EXT2_DEV $DIR/$tdir/ext2-mountpoint"
	touch $DIR/$tdir/test_file
	$CHECKSTAT -t file $DIR/$tdir/ext2-mountpoint/../test_file ||
		error "$DIR/$tdir/ext2-mountpoint/../test_file not file type"
	cleanup_test32_mount
}
run_test 32i "stat d32i/ext2-mountpoint/../test_file ==========="

test_32j() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	[ -e $DIR/$tdir ] && rm -fr $DIR/$tdir
	trap cleanup_test32_mount EXIT
	test_mkdir -p $DIR/$tdir/ext2-mountpoint
	mount -t ext2 -o loop $EXT2_DEV $DIR/$tdir/ext2-mountpoint ||
		error "mount failed for $EXT2_DEV $DIR/$tdir/ext2-mountpoint"
	touch $DIR/$tdir/test_file
	cat $DIR/$tdir/ext2-mountpoint/../test_file ||
		error "Can't open $DIR/$tdir/ext2-mountpoint/../test_file"
	cleanup_test32_mount
}
run_test 32j "open d32j/ext2-mountpoint/../test_file ==========="

test_32k() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	rm -fr $DIR/$tdir
	trap cleanup_test32_mount EXIT
	test_mkdir -p $DIR/$tdir/ext2-mountpoint
	mount -t ext2 -o loop $EXT2_DEV $DIR/$tdir/ext2-mountpoint ||
		error "mount failed for $EXT2_DEV $DIR/$tdir/ext2-mountpoint"
	test_mkdir -p $DIR/$tdir/d2
	touch $DIR/$tdir/d2/test_file || error "touch failed"
	$CHECKSTAT -t file $DIR/$tdir/ext2-mountpoint/../d2/test_file ||
		error "$DIR/$tdir/ext2-mountpoint/../d2/test_file not file type"
	cleanup_test32_mount
}
run_test 32k "stat d32k/ext2-mountpoint/../d2/test_file ========"

test_32l() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	rm -fr $DIR/$tdir
	trap cleanup_test32_mount EXIT
	test_mkdir -p $DIR/$tdir/ext2-mountpoint
	mount -t ext2 -o loop $EXT2_DEV $DIR/$tdir/ext2-mountpoint ||
		error "mount failed for $EXT2_DEV $DIR/$tdir/ext2-mountpoint"
	test_mkdir -p $DIR/$tdir/d2
	touch $DIR/$tdir/d2/test_file || error "touch failed"
	cat  $DIR/$tdir/ext2-mountpoint/../d2/test_file ||
		error "Can't open $DIR/$tdir/ext2-mountpoint/../d2/test_file"
	cleanup_test32_mount
}
run_test 32l "open d32l/ext2-mountpoint/../d2/test_file ========"

test_32m() {
	rm -fr $DIR/d32m
	test_mkdir -p $DIR/d32m/tmp
	TMP_DIR=$DIR/d32m/tmp
	ln -s $DIR $TMP_DIR/symlink11
	ln -s $TMP_DIR/symlink11 $TMP_DIR/../symlink01
	$CHECKSTAT -t link $DIR/d32m/tmp/symlink11 ||
		error "symlink11 not a link"
	$CHECKSTAT -t link $DIR/d32m/symlink01 ||
		error "symlink01 not a link"
}
run_test 32m "stat d32m/symlink->tmp/symlink->yrfs-root ======"

test_32n() {
	rm -fr $DIR/d32n
	test_mkdir -p $DIR/d32n/tmp
	TMP_DIR=$DIR/d32n/tmp
	ln -s $DIR $TMP_DIR/symlink11
	ln -s $TMP_DIR/symlink11 $TMP_DIR/../symlink01
	ls -l $DIR/d32n/tmp/symlink11  || error "listing symlink11"
	ls -l $DIR/d32n/symlink01 || error "listing symlink01"
}
run_test 32n "open d32n/symlink->tmp/symlink->yrfs-root ======"

test_32o() {
	touch $DIR/$tfile
	test_mkdir -p $DIR/d32o/tmp
	TMP_DIR=$DIR/d32o/tmp
	ln -s $DIR/$tfile $TMP_DIR/symlink12
	ln -s $TMP_DIR/symlink12 $TMP_DIR/../symlink02
	$CHECKSTAT -t link $DIR/d32o/tmp/symlink12 ||
		error "symlink12 not a link"
	$CHECKSTAT -t link $DIR/d32o/symlink02 || error "symlink02 not a link"
	$CHECKSTAT -t file -f $DIR/d32o/tmp/symlink12 ||
		error "$DIR/d32o/tmp/symlink12 not file type"
	$CHECKSTAT -t file -f $DIR/d32o/symlink02 ||
		error "$DIR/d32o/symlink02 not file type"
}
run_test 32o "stat d32o/symlink->tmp/symlink->yrfs-root/$tfile"

test_32p() {
	log 32p_1
	rm -fr $DIR/d32p
	log 32p_2
	rm -f $DIR/$tfile
	log 32p_3
	touch $DIR/$tfile
	log 32p_4
	test_mkdir -p $DIR/d32p/tmp
	log 32p_5
	TMP_DIR=$DIR/d32p/tmp
	log 32p_6
	ln -s $DIR/$tfile $TMP_DIR/symlink12
	log 32p_7
	ln -s $TMP_DIR/symlink12 $TMP_DIR/../symlink02
	log 32p_8
	cat $DIR/d32p/tmp/symlink12 ||
		error "Can't open $DIR/d32p/tmp/symlink12"
	log 32p_9
	cat $DIR/d32p/symlink02 || error "Can't open $DIR/d32p/symlink02"
	log 32p_10
}
run_test 32p "open d32p/symlink->tmp/symlink->yrfs-root/$tfile"

test_32q() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	[ -e $DIR/$tdir ] && rm -fr $DIR/$tdir
	trap cleanup_test32_mount EXIT
	test_mkdir -p $DIR/$tdir/ext2-mountpoint
	touch $DIR/$tdir/ext2-mountpoint/under_the_mount || error "touch failed"
	mount -t ext2 -o loop $EXT2_DEV $DIR/$tdir/ext2-mountpoint ||
		error "mount failed for $EXT2_DEV $DIR/$tdir/ext2-mountpoint"
	ls $DIR/$tdir/ext2-mountpoint | grep "\<under_the_mount\>" && error
	cleanup_test32_mount
}
run_test 32q "stat follows mountpoints in yrfs (should return error)"

test_32r() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	[ -e $DIR/$tdir ] && rm -fr $DIR/$tdir
	trap cleanup_test32_mount EXIT
	test_mkdir -p $DIR/$tdir/ext2-mountpoint
	touch $DIR/$tdir/ext2-mountpoint/under_the_mount || error "touch failed"
	mount -t ext2 -o loop $EXT2_DEV $DIR/$tdir/ext2-mountpoint ||
		error "mount failed for $EXT2_DEV $DIR/$tdir/ext2-mountpoint"
	ls $DIR/$tdir/ext2-mountpoint | grep -q under_the_mount && error || true
	cleanup_test32_mount
}
run_test 32r "opendir follows mountpoints in yrfs (should return error)"

test_33aa() {
	rm -f $DIR/$tfile
	touch $DIR/$tfile
	chmod 444 $DIR/$tfile
	chown $RUNAS_ID $DIR/$tfile
	log 33_1
	$RUNAS $OPENFILE -f O_RDWR $DIR/$tfile && error || true
	log 33_2
}
run_test 33aa "write file with mode 444 (should return error)"

test_33a() {
	rm -fr $DIR/$tdir
	test_mkdir $DIR/$tdir
	chown $RUNAS_ID $DIR/$tdir
	$RUNAS $OPENFILE -f O_RDWR:O_CREAT -m 0444 $DIR/$tdir/$tfile ||
		error "$RUNAS create $tdir/$tfile failed"
	$RUNAS $OPENFILE -f O_RDWR:O_CREAT -m 0444 $DIR/$tdir/$tfile &&
		error "open RDWR" || true
}
run_test 33a "test open file(mode=0444) with O_RDWR (should return error)"

test_33b() {
	rm -fr $DIR/$tdir
	test_mkdir $DIR/$tdir
	chown $RUNAS_ID $DIR/$tdir
	$RUNAS $OPENFILE -f 1286739555 $DIR/$tdir/$tfile || true
}
run_test 33b "test open file with malformed flags (No panic)"

test_33c() {
	mkdir -p $DIR/$tdir/dir2

	local err=$($RUNAS mkdir $DIR/$tdir/dir2 2>&1)
	echo $err
	[[ $err =~ "exists" ]] || error "Not exists error"
}
run_test 33c "nonroot user create already existing root created file"

TEST_34_SIZE=${TEST_34_SIZE:-2000000000000}
test_34a() {
	rm -f $DIR/f34
	$MCREATE $DIR/f34 || error "mcreate failed"
	$TRUNCATE $DIR/f34 $TEST_34_SIZE || error "truncate failed"
	$CHECKSTAT -s $TEST_34_SIZE $DIR/f34 ||
		error "Size of $DIR/f34 not equal to $TEST_34_SIZE bytes"
}
run_test 34a "truncate file that has not been opened ==========="

test_34b() {
	[ ! -f $DIR/f34 ] && test_34a
	$CHECKSTAT -s $TEST_34_SIZE $DIR/f34 ||
		error "Size of $DIR/f34 not equal to $TEST_34_SIZE bytes"
	$OPENFILE -f O_RDONLY $DIR/f34
	$CHECKSTAT -s $TEST_34_SIZE $DIR/f34 ||
		error "Size of $DIR/f34 not equal to $TEST_34_SIZE bytes"
}
run_test 34b "O_RDONLY opening file doesn't create objects ====="

test_34c() {
	[ ! -f $DIR/f34 ] && test_34a
	$CHECKSTAT -s $TEST_34_SIZE $DIR/f34 ||
		error "Size of $DIR/f34 not equal to $TEST_34_SIZE bytes"
	$OPENFILE -f O_RDWR $DIR/f34
	$CHECKSTAT -s $TEST_34_SIZE $DIR/f34 ||
		error "Size of $DIR/f34 not equal to $TEST_34_SIZE bytes"
}
run_test 34c "O_RDWR opening file-with-size works =============="

test_34d() {
	[ ! -f $DIR/f34 ] && test_34a
	dd if=/dev/zero of=$DIR/f34 conv=notrunc bs=4k count=1 ||
		error "dd failed"
	$CHECKSTAT -s $TEST_34_SIZE $DIR/f34 ||
		error "Size of $DIR/f34 not equal to $TEST_34_SIZE bytes"
	rm $DIR/f34
}
run_test 34d "write to sparse file ============================="

test_34e() {
	rm -f $DIR/f34e
	$MCREATE $DIR/f34e || error "mcreate failed"
	$TRUNCATE $DIR/f34e 1000 || error "truncate failed"
	$CHECKSTAT -s 1000 $DIR/f34e ||
		error "Size of $DIR/f34e not equal to 1000 bytes"
	$OPENFILE -f O_RDWR $DIR/f34e
	$CHECKSTAT -s 1000 $DIR/f34e ||
		error "Size of $DIR/f34e not equal to 1000 bytes"
}
run_test 34e "create objects, some with size and some without =="

test_34f() { # bug 6242, 6243
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	SIZE34F=48000
	rm -f $DIR/f34f
	$MCREATE $DIR/f34f || error "mcreate failed"
	$TRUNCATE $DIR/f34f $SIZE34F || error "truncating $DIR/f3f to $SIZE34F"
	dd if=$DIR/f34f of=$TMP/f34f
	$CHECKSTAT -s $SIZE34F $TMP/f34f || error "$TMP/f34f not $SIZE34F bytes"
	dd if=/dev/zero of=$TMP/f34fzero bs=$SIZE34F count=1
	cmp $DIR/f34f $TMP/f34fzero || error "$DIR/f34f not all zero"
	cmp $TMP/f34f $TMP/f34fzero || error "$TMP/f34f not all zero"
	rm $TMP/f34f $TMP/f34fzero $DIR/f34f
}
run_test 34f "read from a file with no objects until EOF ======="

test_34g() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	dd if=/dev/zero of=$DIR/$tfile bs=1 count=100 seek=$TEST_34_SIZE ||
		error "dd failed"
	$TRUNCATE $DIR/$tfile $((TEST_34_SIZE / 2))|| error "truncate failed"
	$CHECKSTAT -s $((TEST_34_SIZE / 2)) $DIR/$tfile ||
		error "Size of $DIR/$tfile not equal to $((TEST_34_SIZE / 2))"
	$CHECKSTAT -s $((TEST_34_SIZE / 2)) $DIR/$tfile ||
		error "wrong size after lock cancel"

	$TRUNCATE $DIR/$tfile $TEST_34_SIZE || error "truncate failed"
	$CHECKSTAT -s $TEST_34_SIZE $DIR/$tfile ||
		error "expanding truncate failed"
	$CHECKSTAT -s $TEST_34_SIZE $DIR/$tfile ||
		error "wrong expanded size after lock cancel"
}
run_test 34g "truncate long file ==============================="

test_35a() {
	cp /bin/sh $DIR/f35a
	chmod 444 $DIR/f35a
	chown $RUNAS_ID $DIR/f35a
	$RUNAS $DIR/f35a && error || true
	rm $DIR/f35a
}
run_test 35a "exec file with mode 444 (should return and not leak)"

test_36a() {
	rm -f $DIR/f36
	utime $DIR/f36 || error "utime failed for MDS"
}
run_test 36a "MDS utime check (mknod, utime)"

test_36b() {
	echo "" > $DIR/f36
	utime $DIR/f36 || error "utime failed for OST"
}
run_test 36b "OST utime check (open, utime)"

test_36c() {
	rm -f $DIR/d36/f36
	test_mkdir $DIR/d36
	chown $RUNAS_ID $DIR/d36
	$RUNAS utime $DIR/d36/f36 || error "utime failed for MDS as non-root"
}
run_test 36c "non-root MDS utime check (mknod, utime)"

test_36d() {
	[ ! -d $DIR/d36 ] && test_36c
	echo "" > $DIR/d36/f36
	$RUNAS utime $DIR/d36/f36 || error "utime failed for OST as non-root"
}
run_test 36d "non-root OST utime check (open, utime)"

test_36e() {
	[ $RUNAS_ID -eq $UID ] && skip_env "RUNAS_ID = UID = $UID -- skipping"

	test_mkdir $DIR/$tdir
	touch $DIR/$tdir/$tfile
	$RUNAS utime $DIR/$tdir/$tfile &&
		error "utime worked, expected failure" || true
}
run_test 36e "utime on non-owned file (should return error)"

test_36f() {
	utime $DIR1/f36f -s $DIR2/f36f || error "utime failed for $DIR1/f36f"
}
run_test 36f "allow mtime to get older"

test_38() {
	local file=$DIR/$tfile
	touch $file
	openfile -f O_DIRECTORY $file
	local RC=$?
	local ENOTDIR=20
	[ $RC -eq 0 ] && error "opened file $file with O_DIRECTORY" || true
	[ $RC -eq $ENOTDIR ] || error "error $RC should be ENOTDIR ($ENOTDIR)"
}
run_test 38 "open a regular file with O_DIRECTORY should return -ENOTDIR ==="

test_39a() { # was test_39
	touch $DIR/$tfile
	touch $DIR/${tfile}2
	sleep 2
	$OPENFILE -f O_CREAT:O_TRUNC:O_WRONLY $DIR/${tfile}2
	if [ ! $DIR/${tfile}2 -nt $DIR/$tfile ]; then
		echo "mtime"
		ls -l --full-time $DIR/$tfile $DIR/${tfile}2
		echo "atime"
		ls -lu --full-time $DIR/$tfile $DIR/${tfile}2
		echo "ctime"
		ls -lc --full-time $DIR/$tfile $DIR/${tfile}2
		error "O_TRUNC didn't change timestamps"
	fi
}
run_test 39a "mtime changed on create"

test_39b() {
	test_mkdir -c1 $DIR/$tdir
	cp -p /etc/passwd $DIR/$tdir/fopen
	cp -p /etc/passwd $DIR/$tdir/flink
	cp -p /etc/passwd $DIR/$tdir/funlink
	cp -p /etc/passwd $DIR/$tdir/frename
	ln $DIR/$tdir/funlink $DIR/$tdir/funlink2

	sleep 1
	echo "aaaaaa" >> $DIR/$tdir/fopen
	echo "aaaaaa" >> $DIR/$tdir/flink
	echo "aaaaaa" >> $DIR/$tdir/funlink
	echo "aaaaaa" >> $DIR/$tdir/frename

	local open_new=`stat -c %Y $DIR/$tdir/fopen`
	local link_new=`stat -c %Y $DIR/$tdir/flink`
	local unlink_new=`stat -c %Y $DIR/$tdir/funlink`
	local rename_new=`stat -c %Y $DIR/$tdir/frename`

	cat $DIR/$tdir/fopen > /dev/null
	ln $DIR/$tdir/flink $DIR/$tdir/flink2
	rm -f $DIR/$tdir/funlink2
	mv -f $DIR/$tdir/frename $DIR/$tdir/frename2

	for (( i=0; i < 2; i++ )) ; do
		local open_new2=`stat -c %Y $DIR/$tdir/fopen`
		local link_new2=`stat -c %Y $DIR/$tdir/flink`
		local unlink_new2=`stat -c %Y $DIR/$tdir/funlink`
		local rename_new2=`stat -c %Y $DIR/$tdir/frename2`

		[ $open_new2 -eq $open_new ] || error "open file reverses mtime"
		[ $link_new2 -eq $link_new ] || error "link file reverses mtime"
		[ $unlink_new2 -eq $unlink_new ] || error "unlink file reverses mtime"
		[ $rename_new2 -eq $rename_new ] || error "rename file reverses mtime"
	done
}
run_test 39b "mtime change on open, link, unlink, rename  ======"

# this should be set to past
TEST_39_MTIME=`date -d "1 year ago" +%s`

# bug 11063
test_39c() {
	touch $DIR1/$tfile
	sleep 2
	local mtime0=`stat -c %Y $DIR1/$tfile`

	touch -m -d @$TEST_39_MTIME $DIR1/$tfile
	local mtime1=`stat -c %Y $DIR1/$tfile`
	[ "$mtime1" = $TEST_39_MTIME ] || \
		error "mtime is not set to past: $mtime1, should be $TEST_39_MTIME"

	local d1=`date +%s`
	echo hello >> $DIR1/$tfile
	local d2=`date +%s`
	local mtime2=`stat -c %Y $DIR1/$tfile`
	[ "$mtime2" -ge "$d1" ] && [ "$mtime2" -le "$d2" ] || \
		error "mtime is not updated on write: $d1 <= $mtime2 <= $d2"

	mv $DIR1/$tfile $DIR1/$tfile-1

	for (( i=0; i < 2; i++ )) ; do
		local mtime3=`stat -c %Y $DIR1/$tfile-1`
		[ "$mtime2" = "$mtime3" ] || \
			error "mtime ($mtime2) changed (to $mtime3) on rename"
	done
}
run_test 39c "mtime change on rename ==========================="

# bug 21114
test_39d() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	touch $DIR1/$tfile
	touch -m -d @$TEST_39_MTIME $DIR1/$tfile

	for (( i=0; i < 2; i++ )) ; do
		local mtime=`stat -c %Y $DIR1/$tfile`
		[ $mtime = $TEST_39_MTIME ] || \
			error "mtime($mtime) is not set to $TEST_39_MTIME"
	done
}
run_test 39d "create, utime, stat =============================="

# bug 21114
test_39e() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	touch $DIR1/$tfile
	local mtime1=`stat -c %Y $DIR1/$tfile`

	touch -m -d @$TEST_39_MTIME $DIR1/$tfile

	for (( i=0; i < 2; i++ )) ; do
		local mtime2=`stat -c %Y $DIR1/$tfile`
		[ $mtime2 = $TEST_39_MTIME ] || \
			error "mtime($mtime2) is not set to $TEST_39_MTIME"

	done
}
run_test 39e "create, stat, utime, stat ========================"

# bug 21114
test_39f() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	touch $DIR1/$tfile
	mtime1=`stat -c %Y $DIR1/$tfile`

	sleep 2
	touch -m -d @$TEST_39_MTIME $DIR1/$tfile

	for (( i=0; i < 2; i++ )) ; do
		local mtime2=`stat -c %Y $DIR1/$tfile`
		[ $mtime2 = $TEST_39_MTIME ] || \
			error "mtime($mtime2) is not set to $TEST_39_MTIME"

	done
}
run_test 39f "create, stat, sleep, utime, stat ================="

# bug 11063
test_39g() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	echo hello >> $DIR1/$tfile
	local mtime1=`stat -c %Y $DIR1/$tfile`

	sleep 2
	chmod o+r $DIR1/$tfile

	for (( i=0; i < 2; i++ )) ; do
		local mtime2=`stat -c %Y $DIR1/$tfile`
		[ "$mtime1" = "$mtime2" ] || \
			error "lost mtime: $mtime2, should be $mtime1"
	done
}
run_test 39g "write, chmod, stat ==============================="

# bug 11063
test_39h() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	touch $DIR1/$tfile
	sleep 1

	local d1=`date`
	echo hello >> $DIR1/$tfile
	local mtime1=`stat -c %Y $DIR1/$tfile`

	touch -m -d @$TEST_39_MTIME $DIR1/$tfile
	local d2=`date`
	if [ "$d1" != "$d2" ]; then
		echo "write and touch not within one second"
	else
		for (( i=0; i < 2; i++ )) ; do
			local mtime2=`stat -c %Y $DIR1/$tfile`
			[ "$mtime2" = $TEST_39_MTIME ] || \
				error "lost mtime: $mtime2, should be $TEST_39_MTIME"

		done
	fi
}
run_test 39h "write, utime within one second, stat ============="

test_39i() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	touch $DIR1/$tfile
	sleep 1

	echo hello >> $DIR1/$tfile
	local mtime1=`stat -c %Y $DIR1/$tfile`

	mv $DIR1/$tfile $DIR1/$tfile-1

	for (( i=0; i < 2; i++ )) ; do
		local mtime2=`stat -c %Y $DIR1/$tfile-1`

		[ "$mtime1" = "$mtime2" ] || \
			error "lost mtime: $mtime2, should be $mtime1"

	done
}
run_test 39i "write, rename, stat =============================="

test_39k() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	touch $DIR1/$tfile
	sleep 1

	multiop_bg_pause $DIR1/$tfile oO_RDWR:w2097152_c || error "multiop failed"
	local multipid=$!
	local mtime1=`stat -c %Y $DIR1/$tfile`

	touch -m -d @$TEST_39_MTIME $DIR1/$tfile

	kill -USR1 $multipid
	wait $multipid || error "multiop close failed"

	for (( i=0; i < 2; i++ )) ; do
		local mtime2=`stat -c %Y $DIR1/$tfile`

		[ "$mtime2" = $TEST_39_MTIME ] || \
			error "mtime is lost on close: $mtime2, should be $TEST_39_MTIME"
	done
}
run_test 39k "write, utime, close, stat ========================"

test_39m() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	touch $DIR1/$tfile
	sleep 2
	local far_past_mtime=$(date -d "May 29 1953" +%s)
	local far_past_atime=$(date -d "Dec 17 1903" +%s)

	touch -m -d @$far_past_mtime $DIR1/$tfile
	touch -a -d @$far_past_atime $DIR1/$tfile

	for (( i=0; i < 2; i++ )) ; do
		local timestamps=$(stat -c "%X %Y" $DIR1/$tfile)
		[ "$timestamps" = "$far_past_atime $far_past_mtime" ] || \
			error "atime or mtime set incorrectly"
	done
}
run_test 39m "test atime and mtime before 1970"

test_39o() {
	TESTDIR=$DIR/$tdir/$tfile
	[ -e $TESTDIR ] && rm -rf $TESTDIR
	mkdir -p $TESTDIR
	cd $TESTDIR
	links1=2
	ls
	mkdir a b
	ls
	links2=$(stat -c %h .)
	[ $(($links1 + 2)) != $links2 ] &&
		error "wrong links count $(($links1 + 2)) != $links2"
	rmdir b
	links3=$(stat -c %h .)
	[ $(($links1 + 1)) != $links3 ] &&
		error "wrong links count $links1 != $links3"
	return 0
}
run_test 39o "directory cached attributes updated after create"

test_39q() { # LU-8041
	local testdir=$DIR/$tdir
	mkdir -p $testdir
	multiop_bg_pause $testdir D_c || error "multiop failed"
	local multipid=$!
	kill -USR1 $multipid
	local atime=$(stat -c %X $testdir)
	[ "$atime" -ne 0 ] || error "atime is zero"
}
run_test 39q "close won't zero out atime"

test_40() {
	dd if=/dev/zero of=$DIR/$tfile bs=4096 count=1
	$RUNAS $OPENFILE -f O_WRONLY:O_TRUNC $DIR/$tfile &&
		error "openfile O_WRONLY:O_TRUNC $tfile failed"
	$CHECKSTAT -t file -s 4096 $DIR/$tfile ||
		error "$tfile is not 4096 bytes in size"
}
run_test 40 "failed open(O_TRUNC) doesn't truncate ============="

test_41() {
	# bug 1553
	small_write $DIR/f41 18
}
run_test 41 "test small file write + fstat ====================="

# decent default
WRITEBACK_SAVE=500
DIRTY_RATIO_SAVE=40
MAX_DIRTY_RATIO=50
BG_DIRTY_RATIO_SAVE=10
MAX_BG_DIRTY_RATIO=25

start_writeback() {
	trap 0
	# in 2.6, restore /proc/sys/vm/dirty_writeback_centisecs,
	# dirty_ratio, dirty_background_ratio
	if [ -f /proc/sys/vm/dirty_writeback_centisecs ]; then
		sysctl -w vm.dirty_writeback_centisecs=$WRITEBACK_SAVE
		sysctl -w vm.dirty_background_ratio=$BG_DIRTY_RATIO_SAVE
		sysctl -w vm.dirty_ratio=$DIRTY_RATIO_SAVE
	else
		# if file not here, we are a 2.4 kernel
		kill -CONT `pidof kupdated`
	fi
}

stop_writeback() {
	# setup the trap first, so someone cannot exit the test at the
	# exact wrong time and mess up a machine
	trap start_writeback EXIT
	# in 2.6, save and 0 /proc/sys/vm/dirty_writeback_centisecs
	if [ -f /proc/sys/vm/dirty_writeback_centisecs ]; then
		WRITEBACK_SAVE=`sysctl -n vm.dirty_writeback_centisecs`
		sysctl -w vm.dirty_writeback_centisecs=0
		sysctl -w vm.dirty_writeback_centisecs=0
		# save and increase /proc/sys/vm/dirty_ratio
		DIRTY_RATIO_SAVE=`sysctl -n vm.dirty_ratio`
		sysctl -w vm.dirty_ratio=$MAX_DIRTY_RATIO
		# save and increase /proc/sys/vm/dirty_background_ratio
		BG_DIRTY_RATIO_SAVE=`sysctl -n vm.dirty_background_ratio`
		sysctl -w vm.dirty_background_ratio=$MAX_BG_DIRTY_RATIO
	else
		# if file not here, we are a 2.4 kernel
		kill -STOP `pidof kupdated`
	fi
}

#write/read test
test_43A() { # was test_43
	test_mkdir $DIR/$tdir
	cp -p /bin/ls $DIR/$tdir/$tfile
	$MULTIOP $DIR/$tdir/$tfile Ow_c &
	pid=$!
	# give multiop a chance to open
	sleep 1

	$DIR/$tdir/$tfile && error "execute $DIR/$tdir/$tfile succeeded" || true
	kill -USR1 $pid
	# Wait for multiop to exit
	wait $pid
}
run_test 43A "execution of file opened for write should return -ETXTBSY"

test_43a() {
	test_mkdir $DIR/$tdir
	cp -p $(which sleep) $DIR/$tdir/sleep || error "can't copy"
	$DIR/$tdir/sleep 60 &
	SLEEP_PID=$!
	# Make sure exec of $tdir/sleep wins race with truncate
	sleep 1
	$MULTIOP $DIR/$tdir/sleep Oc && error "expected error, got success"
	kill $SLEEP_PID
}
run_test 43a "open(RDWR) of file being executed should return -ETXTBSY"

test_43b() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	test_mkdir $DIR/$tdir
	cp -p $(which sleep) $DIR/$tdir/sleep || error "can't copy"
	$DIR/$tdir/sleep 60 &
	SLEEP_PID=$!
	# Make sure exec of $tdir/sleep wins race with truncate
	sleep 1
	$TRUNCATE $DIR/$tdir/sleep 0 && error "expected error, got success"
	kill $SLEEP_PID
}
run_test 43b "truncate of file being executed should return -ETXTBSY"

test_43c() {
	local testdir="$DIR/$tdir"
	test_mkdir $testdir
	cp $SHELL $testdir/
	( cd $(dirname $SHELL) && md5sum $(basename $SHELL) ) |
		( cd $testdir && md5sum -c )
}
run_test 43c "md5sum of copy into yrfs"

test_44A() { # was test_44
	[[ $OSTCOUNT -lt 2 ]] && skip_env "needs >= 2 OSTs"

	dd if=/dev/zero of=$DIR/f1 bs=4k count=1 seek=1023
	dd if=$DIR/f1 bs=4k count=1 > /dev/null
}
run_test 44A "zero length read from a sparse stripe"

#unavailable
test_44a() {
	local nstripe=$($LFS getstripe -c -d $DIR)
	[ -z "$nstripe" ] && skip "can't get stripe info"
	[[ $nstripe -gt $OSTCOUNT ]] &&
		skip "Wrong default stripe_count: $nstripe OSTCOUNT: $OSTCOUNT"

	local stride=$($LFS getstripe -S -d $DIR)
	if [[ $nstripe -eq 0 || $nstripe -eq -1 ]]; then
		nstripe=$($LFS df $DIR | grep OST: | wc -l)
	fi

	OFFSETS="0 $((stride/2)) $((stride-1))"
	for offset in $OFFSETS; do
		for i in $(seq 0 $((nstripe-1))); do
			local GLOBALOFFSETS=""
			# size in Bytes
			local size=$((((i + 2 * $nstripe )*$stride + $offset)))
			local myfn=$DIR/d44a-$size
			echo "--------writing $myfn at $size"
			ll_sparseness_write $myfn $size ||
				error "ll_sparseness_write"
			GLOBALOFFSETS="$GLOBALOFFSETS $size"
			ll_sparseness_verify $myfn $GLOBALOFFSETS ||
				error "ll_sparseness_verify $GLOBALOFFSETS"

			for j in $(seq 0 $((nstripe-1))); do
				# size in Bytes
				size=$((((j + $nstripe )*$stride + $offset)))
				ll_sparseness_write $myfn $size ||
					error "ll_sparseness_write"
				GLOBALOFFSETS="$GLOBALOFFSETS $size"
			done
			ll_sparseness_verify $myfn $GLOBALOFFSETS ||
				error "ll_sparseness_verify $GLOBALOFFSETS"
			rm -f $myfn
		done
	done
}
#run_test 44a "test sparse pwrite ==============================="

# in a 2 stripe file (lov.sh), page 1023 maps to page 511 in its object.  this
# test tickles a bug where re-dirtying a page was failing to be mapped to the
# objects offset and an assert hit when an rpc was built with 1023's mapped
# offset 511 and 511's raw 511 offset. it also found general redirtying bugs.
test_46() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	f="$DIR/f46"
	stop_writeback
	sync
	dd if=/dev/zero of=$f bs=$PAGE_SIZE seek=511 count=1
	sync
	dd conv=notrunc if=/dev/zero of=$f bs=$PAGE_SIZE seek=1023 count=1
	dd conv=notrunc if=/dev/zero of=$f bs=$PAGE_SIZE seek=511 count=1
	sync
	start_writeback
}
run_test 46 "dirtying a previously written page ================"

# test_47 is removed "Device nodes check" is moved to test_28

test_48a() { # bug 2399
	test_mkdir $DIR/$tdir
	cd $DIR/$tdir
	mv $DIR/$tdir $DIR/$tdir.new || error "move directory failed"
	test_mkdir $DIR/$tdir
	touch foo || error "'touch foo' failed after recreating cwd"
	test_mkdir bar
	touch .foo || error "'touch .foo' failed after recreating cwd"
	test_mkdir .bar
	ls . > /dev/null || error "'ls .' failed after recreating cwd"
	ls .. > /dev/null || error "'ls ..' failed after removing cwd"
	cd . || error "'cd .' failed after recreating cwd"
	mkdir . && error "'mkdir .' worked after recreating cwd"
	rmdir . && error "'rmdir .' worked after recreating cwd"
	ln -s . baz || error "'ln -s .' failed after recreating cwd"
	cd .. || error "'cd ..' failed after recreating cwd"
}
run_test 48a "Access renamed working dir (should return errors)="

test_48b() { # bug 2399
	rm -rf $DIR/$tdir
	test_mkdir $DIR/$tdir
	cd $DIR/$tdir
	rmdir $DIR/$tdir || error "remove cwd $DIR/$tdir failed"
	touch foo && error "'touch foo' worked after removing cwd"
	mkdir foo && error "'mkdir foo' worked after removing cwd"
	touch .foo && error "'touch .foo' worked after removing cwd"
	mkdir .foo && error "'mkdir .foo' worked after removing cwd"
	ls . > /dev/null && error "'ls .' worked after removing cwd"
	ls .. > /dev/null || error "'ls ..' failed after removing cwd"
	mkdir . && error "'mkdir .' worked after removing cwd"
	rmdir . && error "'rmdir .' worked after removing cwd"
	ln -s . foo && error "'ln -s .' worked after removing cwd"
	cd .. || echo "'cd ..' failed after removing cwd `pwd`"  #bug 3517
}
run_test 48b "Access removed working dir (should return errors)="

test_48c() { # bug 2350
	rm -rf $DIR/$tdir
	test_mkdir -p $DIR/$tdir/dir
	cd $DIR/$tdir/dir
	$TRACE rmdir $DIR/$tdir/dir || error "remove cwd $DIR/$tdir/dir failed"
	$TRACE touch foo && error "touch foo worked after removing cwd"
	$TRACE mkdir foo && error "'mkdir foo' worked after removing cwd"
	touch .foo && error "touch .foo worked after removing cwd"
	mkdir .foo && error "mkdir .foo worked after removing cwd"
	$TRACE ls . && error "'ls .' worked after removing cwd"
	$TRACE ls .. || error "'ls ..' failed after removing cwd"
	$TRACE mkdir . && error "'mkdir .' worked after removing cwd"
	$TRACE rmdir . && error "'rmdir .' worked after removing cwd"
	$TRACE ln -s . foo && error "'ln -s .' worked after removing cwd"
	$TRACE cd .. || echo "'cd ..' failed after removing cwd `pwd`" #bug 3415
}
run_test 48c "Access removed working subdir (should return errors)"

test_48d() { # bug 2350
	rm -rf $DIR/$tdir
	test_mkdir -p $DIR/$tdir/dir
	cd $DIR/$tdir/dir
	$TRACE rmdir $DIR/$tdir/dir || error "remove cwd $DIR/$tdir/dir failed"
	$TRACE rmdir $DIR/$tdir || error "remove parent $DIR/$tdir failed"
	$TRACE touch foo && error "'touch foo' worked after removing parent"
	$TRACE mkdir foo && error "mkdir foo worked after removing parent"
	touch .foo && error "'touch .foo' worked after removing parent"
	mkdir .foo && error "mkdir .foo worked after removing parent"
	$TRACE ls . && error "'ls .' worked after removing parent"
	$TRACE ls .. && error "'ls ..' worked after removing parent"
	$TRACE mkdir . && error "'mkdir .' worked after removing parent"
	$TRACE rmdir . && error "'rmdir .' worked after removing parent"
	$TRACE ln -s . foo && error "'ln -s .' worked after removing parent"
	true
}
run_test 48d "Access removed parent subdir (should return errors)"

test_48e() { # bug 4134
	#lctl set_param debug=-1
	#set -vx
	rm -rf $DIR/$tdir
	test_mkdir -p $DIR/$tdir/dir
	cd $DIR/$tdir/dir
	$TRACE rmdir $DIR/$tdir/dir || error "remove cwd $DIR/$tdir/dir failed"
	$TRACE rmdir $DIR/$tdir || error "remove parent $DIR/$tdir failed"
	$TRACE touch $DIR/$tdir || error "'touch $DIR/$tdir' failed"
	$TRACE chmod +x $DIR/$tdir || error "'chmod +x $DIR/$tdir' failed"
	# On a buggy kernel addition of "touch foo" after cd .. will
	# produce kernel oops in lookup_hash_it
	touch ../foo && error "'cd ..' worked after recreate parent"
	cd $DIR
	$TRACE rm $DIR/$tdir || error "rm '$DIR/$tdir' failed"
}
run_test 48e "Access to recreated parent subdir (should return errors)"

test_50() {
	# bug 1485
	test_mkdir $DIR/$tdir
	cd $DIR/$tdir
	ls /proc/$$/cwd || error "ls /proc/$$/cwd failed"
}
run_test 50 "special situations: /proc symlinks  ==============="

test_51a() {	# was test_51
	# bug 1516 - create an empty entry right after ".." then split dir
	test_mkdir -c1 $DIR/$tdir
	touch $DIR/$tdir/foo
	$MCREATE $DIR/$tdir/bar
	rm $DIR/$tdir/foo
	createmany -m $DIR/$tdir/longfile 201
	FNUM=202
	while [[ $(ls -sd $DIR/$tdir | awk '{ print $1 }') -eq 4 ]]; do
		$MCREATE $DIR/$tdir/longfile$FNUM
		FNUM=$(($FNUM + 1))
		echo -n "+"
	done
	echo
	ls -l $DIR/$tdir > /dev/null || error "ls -l $DIR/$tdir failed"
}
run_test 51a "special situations: split htree with empty entry =="

test_51e() {
	test_mkdir -c1 $DIR/$tdir
	test_mkdir -c1 $DIR/$tdir/d0

	touch $DIR/$tdir/d0/foo
	createmany -l $DIR/$tdir/d0/foo $DIR/$tdir/d0/f- 65001 &&
		error "file exceed 65000 nlink limit!"
	unlinkmany $DIR/$tdir/d0/f- 65001
	return 0
}
run_test 51e "check file nlink limit"

test_52a() {
	[ -f $DIR/$tdir/foo ] && chattr -a $DIR/$tdir/foo
	test_mkdir $DIR/$tdir
	touch $DIR/$tdir/foo
	chattr +a $DIR/$tdir/foo || error "chattr +a failed"
	echo bar >> $DIR/$tdir/foo || error "append bar failed"
	cp /etc/hosts $DIR/$tdir/foo && error "cp worked"
	rm -f $DIR/$tdir/foo 2>/dev/null && error "rm worked"
	link $DIR/$tdir/foo $DIR/$tdir/foo_link 2>/dev/null &&
					error "link worked"
	echo foo >> $DIR/$tdir/foo || error "append foo failed"
	mrename $DIR/$tdir/foo $DIR/$tdir/foo_ren && error "rename worked"
	lsattr $DIR/$tdir/foo | egrep -q "^-+a[-e]+ $DIR/$tdir/foo" ||
						     error "lsattr"
	chattr -a $DIR/$tdir/foo || error "chattr -a failed"
	cp -r $DIR/$tdir $TMP/
	rm -fr $DIR/$tdir $TMP/$tdir || error "cleanup rm failed"
}
run_test 52a "append-only flag test (should return errors)"

test_52b() {
	[ -f $DIR/$tdir/foo ] && chattr -i $DIR/$tdir/foo
	test_mkdir $DIR/$tdir
	touch $DIR/$tdir/foo
	chattr +i $DIR/$tdir/foo || error "chattr +i failed"
	cat test > $DIR/$tdir/foo && error "cat test worked"
	cp /etc/hosts $DIR/$tdir/foo && error "cp worked"
	rm -f $DIR/$tdir/foo 2>/dev/null && error "rm worked"
	link $DIR/$tdir/foo $DIR/$tdir/foo_link 2>/dev/null &&
					error "link worked"
	echo foo >> $DIR/$tdir/foo && error "echo worked"
	mrename $DIR/$tdir/foo $DIR/$tdir/foo_ren && error "rename worked"
	[ -f $DIR/$tdir/foo ] || error "$tdir/foo is not a file"
	[ -f $DIR/$tdir/foo_ren ] && error "$tdir/foo_ren is not a file"
	lsattr $DIR/$tdir/foo | egrep -q "^-+i[-e]+ $DIR/$tdir/foo" ||
							error "lsattr"
	chattr -i $DIR/$tdir/foo || error "chattr failed"

	rm -fr $DIR/$tdir || error "unable to remove $DIR/$tdir"
}
run_test 52b "immutable flag test (should return errors) ======="

test_54a() {
	perl -MSocket -e ';' || skip "no Socket perl module installed"

	$SOCKETSERVER $DIR/socket ||
		error "$SOCKETSERVER $DIR/socket failed: $?"
	$SOCKETCLIENT $DIR/socket ||
		error "$SOCKETCLIENT $DIR/socket failed: $?"
	$MUNLINK $DIR/socket || error "$MUNLINK $DIR/socket failed: $?"
}
run_test 54a "unix domain socket test =========================="

test_54b() {
	f="$DIR/f54b"
	mknod $f c 1 3
	chmod 0666 $f
	dd if=/dev/zero of=$f bs=$PAGE_SIZE count=1 || error "${f} dd fail"
}
run_test 54b "char device works in yrfs ======================"

find_loop_dev() {
	[ -b /dev/loop/0 ] && LOOPBASE=/dev/loop/
	[ -b /dev/loop0 ] && LOOPBASE=/dev/loop
	[ -z "$LOOPBASE" ] && echo "/dev/loop/0 and /dev/loop0 gone?" && return

	for i in $(seq 3 7); do
		losetup $LOOPBASE$i > /dev/null 2>&1 && continue
		LOOPDEV=$LOOPBASE$i
		LOOPNUM=$i
		break
	done
}

cleanup_54c() {
	local rc=0
	loopdev="$DIR/loop54c"

	trap 0
	$UMOUNT $DIR/$tdir || rc=$?
	losetup -d $loopdev || true
	losetup -d $LOOPDEV || true
	rm -rf $loopdev $DIR/$tfile $DIR/$tdir
	return $rc
}

test_54c() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	loopdev="$DIR/loop54c"

	find_loop_dev
	[ -z "$LOOPNUM" ] && skip_env "couldn't find empty loop device"
	trap cleanup_54c EXIT
	mknod $loopdev b 7 $LOOPNUM
	echo "make a loop file system with $DIR/$tfile on $loopdev ($LOOPNUM)."
	dd if=/dev/zero of=$DIR/$tfile bs=$PAGE_SIZE seek=1024 count=1 > /dev/null
	losetup $loopdev $DIR/$tfile ||
		error "can't set up $loopdev for $DIR/$tfile"
	mkfs.ext2 $loopdev || error "mke2fs on $loopdev"
	test_mkdir $DIR/$tdir
	mount -t ext2 $loopdev $DIR/$tdir ||
		error "error mounting $loopdev on $DIR/$tdir"
	dd if=/dev/zero of=$DIR/$tdir/tmp bs=$PAGE_SIZE count=30 ||
		error "dd write"
	df $DIR/$tdir
	dd if=$DIR/$tdir/tmp of=/dev/zero bs=$PAGE_SIZE count=30 ||
		error "dd read"
	cleanup_54c
}
run_test 54c "block device works in yrfs ====================="

test_54d() {
	f="$DIR/f54d"
	string="aaaaaa"
	mknod $f p
	[ "$string" = $(echo $string > $f | cat $f) ] || error "$f != $string"
}
run_test 54d "fifo device works in yrfs ======================"

test_54e() {
	f="$DIR/f54e"
	string="aaaaaa"
	cp -aL /dev/console $f
	echo $string > $f || error "echo $string to $f failed"
}
run_test 54e "console/tty device works in yrfs ======================"

test_58() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"
	[ -z "$(which wiretest 2>/dev/null)" ] &&
			skip_env "could not find wiretest"

	wiretest
}
#run_test 58 "verify cross-platform wire constants =============="

test_59() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	echo "touch 130 files"
	createmany -o $DIR/f59- 130
	echo "rm 130 files"
	unlinkmany $DIR/f59- 130
	sync
	# wait for commitment of removal
	# wait_delete_completed
}
run_test 59 "verify cancellation of llog records async ========="

test_61a() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	f="$DIR/f61"
	dd if=/dev/zero of=$f bs=$PAGE_SIZE count=1 || error "dd $f failed"
	$MULTIOP $f OSMWUc || error "$MULTIOP $f failed"
	sync
}
run_test 61a "mmap() writes don't make sync hang ================"

test_61b() {
	mmap_mknod_test $DIR/$tfile || error "mmap_mknod_test failed"
}
run_test 61b "mmap() of unstriped file is successful"

test_64b () {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	sh oos.sh $MOUNT || error "oos.sh failed: $?"
}
#run_test 64b "check out-of-space detection on client"

round_up_p2() {
	echo $((($1 + $2 - 1) & ~($2 - 1)))
}

# bug 2543 - update blocks count on client
test_66() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	COUNT=${COUNT:-8}
	dd if=/dev/zero of=$DIR/f66 bs=1k count=$COUNT
#	sync; sync_all_data; sync; sync_all_data
#	cancel_lru_locks osc
	BLOCKS=`ls -s $DIR/f66 | awk '{ print $1 }'`
	[ $BLOCKS -ge $COUNT ] || error "$DIR/f66 blocks $BLOCKS < $COUNT"
}
run_test 66 "update inode blocks count on client ==============="

meminfo() {
	awk '($1 == "'$1':") { print $2 }' /proc/meminfo
}

swap_used() {
	swapon -s | awk '($1 == "'$1'") { print $4 }'
}

test_72a() { # bug 5695 - Test that on 2.6 remove_suid works properly
	[ $PARALLEL == "yes" ] && skip "skip parallel run"
	[ "$RUNAS_ID" = "$UID" ] &&
		skip_env "RUNAS_ID = UID = $UID -- skipping"
	# Check that testing environment is properly set up. Skip if not
	#FAIL_ON_ERROR=false check_runas_id_ret $RUNAS_ID $RUNAS_GID $RUNAS ||
	#	skip_env "User $RUNAS_ID does not exist - skipping"

	touch $DIR/$tfile
	chmod 777 $DIR/$tfile
	chmod ug+s $DIR/$tfile
	$RUNAS dd if=/dev/zero of=$DIR/$tfile bs=512 count=1 ||
		error "$RUNAS dd $DIR/$tfile failed"
	# See if we are still setuid/sgid
	[ -u $DIR/$tfile ] || [ -g $DIR/$tfile ] &&
		error "S/gid is not dropped on write"
	# Now test that MDS is updated too
	[ -u $DIR/$tfile ] || [ -g $DIR/$tfile ] &&
		error "S/gid is not dropped on MDS"
	rm -f $DIR/$tfile
}
#run_test 72a "Test that remove suid works properly (bug5695) ===="

test_72b() { # bug 24226 -- keep mode setting when size is not changing
	local perm

	[ "$RUNAS_ID" = "$UID" ] &&
		skip_env "RUNAS_ID = UID = $UID -- skipping"
	[ "$RUNAS_ID" -eq 0 ] &&
		skip_env "RUNAS_ID = 0 -- skipping"
	[ $PARALLEL == "yes" ] && skip "skip parallel run"
	# Check that testing environment is properly set up. Skip if not
	#FAIL_ON_ERROR=false check_runas_id_ret $RUNAS_ID $RUNAS_ID $RUNAS ||
	#	skip_env "User $RUNAS_ID does not exist - skipping"

	touch $DIR/${tfile}-f{g,u}
	test_mkdir $DIR/${tfile}-dg
	test_mkdir $DIR/${tfile}-du
	chmod 770 $DIR/${tfile}-{f,d}{g,u}
	chmod g+s $DIR/${tfile}-{f,d}g
	chmod u+s $DIR/${tfile}-{f,d}u
	for perm in 777 2777 4777; do
		$RUNAS chmod $perm $DIR/${tfile}-fg && error "S/gid file allowed improper chmod to $perm"
		$RUNAS chmod $perm $DIR/${tfile}-fu && error "S/uid file allowed improper chmod to $perm"
		$RUNAS chmod $perm $DIR/${tfile}-dg && error "S/gid dir allowed improper chmod to $perm"
		$RUNAS chmod $perm $DIR/${tfile}-du && error "S/uid dir allowed improper chmod to $perm"
	done
	true
}
#run_test 72b "Test that we keep mode setting if without file data changed (bug 24226)"

slab_lic=/sys/kernel/slab/yrfs_icache
num_objects() {
	[ -f $slab_lic/shrink ] && echo 1 > $slab_lic/shrink
	[ -f $slab_lic/objects ] && awk '{ print $1 }' $slab_lic/objects ||
		awk '/yrfs_inode_cache/ { print $2; exit }' /proc/slabinfo
}

test_76a() { # Now for b=20433, added originally in b=1443
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	# there may be some slab objects cached per core
	local cpus=$(getconf _NPROCESSORS_ONLN 2>/dev/null)
	local before=$(num_objects)
	local count=$((512 * cpus))
	[ "$SLOW" = "no" ] && count=$((128 * cpus))
	local margin=$((count / 10))
	if [[ -f $slab_lic/aliases ]]; then
		local aliases=$(cat $slab_lic/aliases)
		(( aliases > 0 )) && margin=$((margin * aliases))
	fi

	echo "before slab objects: $before"
	for i in $(seq $count); do
		touch $DIR/$tfile
		rm -f $DIR/$tfile
	done
	local after=$(num_objects)
	echo "created: $count, after slab objects: $after"
	# shared slab counts are not very accurate, allow significant margin
	# the main goal is that the cache growth is not permanently > $count
	while (( after > before + margin )); do
		sleep 1
		after=$(num_objects)
		wait=$((wait + 1))
		(( wait % 5 == 0 )) && echo "wait $wait seconds objects: $after"
		if (( wait > 60 )); then
			error "inode slab grew from $before+$margin to $after"
		fi
	done
}
run_test 76a "confirm clients recycle inodes properly ===="

test_76b() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	local count=512
	local before=$(num_objects)

	for i in $(seq $count); do
		mkdir $DIR/$tdir
		rmdir $DIR/$tdir
	done

	local after=$(num_objects)
	local wait=0

	while (( after > before )); do
		sleep 1
		after=$(num_objects)
		wait=$((wait + 1))
		(( wait % 5 == 0 )) && echo "wait $wait seconds objects: $after"
		if (( wait > 60 )); then
			error "inode slab grew from $before to $after"
		fi
	done

	echo "slab objects before: $before, after: $after"
}
run_test 76b "confirm clients recycle directory inodes properly ===="

export ORIG_CSUM=""
set_checksums()
{
	# Note: in sptlrpc modes which enable its own bulk checksum, the
	# original crc32_le bulk checksum will be automatically disabled,
	# and the OBD_FAIL_OSC_CHECKSUM_SEND/OBD_FAIL_OSC_CHECKSUM_RECEIVE
	# will be checked by sptlrpc code against sptlrpc bulk checksum.
	# In this case set_checksums() will not be no-op, because sptlrpc
	# bulk checksum will be enabled all through the test.

	[ "$ORIG_CSUM" ] || ORIG_CSUM=`lctl get_param -n osc.*.checksums | head -n1`
        lctl set_param -n osc.*.checksums $1
	return 0
}

#export ORIG_CSUM_TYPE="`lctl get_param -n osc.*osc-[^mM]*.checksum_type |
#                        sed 's/.*\[\(.*\)\].*/\1/g' | head -n1`"
#CKSUM_TYPES=${CKSUM_TYPES:-$(lctl get_param -n osc.*osc-[^mM]*.checksum_type |
#			     tr -d [] | head -n1)}
set_checksum_type()
{
	lctl set_param -n osc.*osc-[^mM]*.checksum_type $1
	rc=$?
	log "set checksum type to $1, rc = $rc"
	return $rc
}

get_osc_checksum_type()
{
	# arugment 1: OST name, like OST0000
	ost=$1
	checksum_type=$(lctl get_param -n osc.*${ost}-osc-[^mM]*.checksum_type |
			sed 's/.*\[\(.*\)\].*/\1/g')
	rc=$?
	[ $rc -ne 0 ] && error "failed to get checksum type of $ost, rc = $rc, output = $checksum_type"
	echo $checksum_type
}

F77_TMP=$TMP/f77-temp
F77SZ=8
setup_f77() {
	dd if=/dev/urandom of=$F77_TMP bs=1M count=$F77SZ || \
		error "error writing to $F77_TMP"
}

test_77a() { # bug 10889
	[ $PARALLEL == "yes" ] && skip "skip parallel run"
	$GSS && skip_env "could not run with gss"

	[ ! -f $F77_TMP ] && setup_f77
	dd if=$F77_TMP of=$DIR/$tfile bs=1M count=$F77SZ || error "dd error"
	rm -f $DIR/$tfile
}
run_test 77a "normal checksum read/write operation"

[ "$ORIG_CSUM" ] && set_checksums $ORIG_CSUM || true
rm -f $F77_TMP
unset F77_TMP

check_filefrag_77n() {
	local nr_ext=0
	local starts=()
	local ends=()

	while read extidx a b start end rest; do
		if [[ "${extidx}" =~ ^[0-9]+: ]]; then
			nr_ext=$(( $nr_ext + 1 ))
			starts+=( ${start%..} )
			ends+=( ${end%:} )
		fi
	done < <( filefrag -sv $1 )

	[[ $nr_ext -eq 2 ]] && [[ "${starts[-1]}" == $(( ${ends[0]} + 1 )) ]] && return 0
	return 1
}

test_77n() {
	touch $DIR/$tfile
	$TRUNCATE $DIR/$tfile 0
	dd if=/dev/urandom of=$DIR/$tfile bs=4k conv=notrunc count=1 seek=0
	dd if=/dev/urandom of=$DIR/$tfile bs=4k conv=notrunc count=1 seek=2
	check_filefrag_77n $DIR/$tfile ||
		skip "$tfile blocks not contiguous around hole"

	set_checksums 1
	stack_trap "set_checksums $ORIG_CSUM" EXIT
	stack_trap "set_checksum_type $ORIG_CSUM_TYPE" EXIT
	stack_trap "rm -f $DIR/$tfile"

	for algo in $CKSUM_TYPES; do
		if [[ "$algo" =~ ^t10 ]]; then
			set_checksum_type $algo ||
				error "fail to set checksum type $algo"
			dd if=$DIR/$tfile of=/dev/null bs=12k count=1 iflag=direct ||
				error "fail to read $tfile with $algo"
		fi
	done
	rm -f $DIR/$tfile
	return 0
}
#run_test 77n "Verify read from a hole inside contiguous blocks with T10PI"

cleanup_test_78() {
	trap 0
	rm -f $DIR/$tfile
}

test_78() { # bug 10901
	[ $PARALLEL == "yes" ] && skip "skip parallel run"
	remote_ost || skip_env "local OST"

	NSEQ=5
	F78SIZE=$(($(awk '/MemFree:/ { print $2 }' /proc/meminfo) / 1024))
	echo "MemFree: $F78SIZE, Max file size: $MAXFREE"
	MEMTOTAL=$(($(awk '/MemTotal:/ { print $2 }' /proc/meminfo) / 1024))
	echo "MemTotal: $MEMTOTAL"

	# reserve 256MB of memory for the kernel and other running processes,
	# and then take 1/2 of the remaining memory for the read/write buffers.
	if [ $MEMTOTAL -gt 512 ] ;then
		MEMTOTAL=$(((MEMTOTAL - 256 ) / 2))
	else
		# for those poor memory-starved high-end clusters...
		MEMTOTAL=$((MEMTOTAL / 2))
	fi
	echo "Mem to use for directio: $MEMTOTAL"

	[[ $F78SIZE -gt $MEMTOTAL ]] && F78SIZE=$MEMTOTAL
	[[ $F78SIZE -gt 512 ]] && F78SIZE=512
	[[ $F78SIZE -gt $((MAXFREE / 1024)) ]] && F78SIZE=$((MAXFREE / 1024))
	SMALLESTOST=$($LFS df $DIR | grep OST | awk '{ print $4 }' | sort -n |
		head -n1)
	echo "Smallest OST: $SMALLESTOST"
	[[ $SMALLESTOST -lt 10240 ]] &&
		skip "too small OSTSIZE, useless to run large O_DIRECT test"

	trap cleanup_test_78 EXIT

	[[ $F78SIZE -gt $((SMALLESTOST * $OSTCOUNT / 1024 - 80)) ]] &&
		F78SIZE=$((SMALLESTOST * $OSTCOUNT / 1024 - 80))

	[ "$SLOW" = "no" ] && NSEQ=1 && [ $F78SIZE -gt 32 ] && F78SIZE=32
	echo "File size: $F78SIZE"
	$LFS setstripe -c $OSTCOUNT $DIR/$tfile || error "setstripe failed"
	for i in $(seq 1 $NSEQ); do
		FSIZE=$(($F78SIZE / ($NSEQ - $i + 1)))
		echo directIO rdwr round $i of $NSEQ
		$DIRECTIO rdwr $DIR/$tfile 0 $FSIZE 1048576||error "rdwr failed"
	done

	cleanup_test_78
}
#run_test 78 "handle large O_DIRECT writes correctly ============"

test_79() { # bug 12743
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	BKTOTAL=$(calc_osc_kbytes kbytestotal)
	BKFREE=$(calc_osc_kbytes kbytesfree)
	BKAVAIL=$(calc_osc_kbytes kbytesavail)

        STRING=`df -P $MOUNT | tail -n 1 | awk '{print $2","$3","$4}'`
        DFTOTAL=`echo $STRING | cut -d, -f1`
        DFUSED=`echo $STRING  | cut -d, -f2`
        DFAVAIL=`echo $STRING | cut -d, -f3`
        DFFREE=$(($DFTOTAL - $DFUSED))

        ALLOWANCE=$((64 * $OSTCOUNT))

        if [ $DFTOTAL -lt $(($BKTOTAL - $ALLOWANCE)) ] ||
           [ $DFTOTAL -gt $(($BKTOTAL + $ALLOWANCE)) ] ; then
                error "df total($DFTOTAL) mismatch OST total($BKTOTAL)"
        fi
        if [ $DFFREE -lt $(($BKFREE - $ALLOWANCE)) ] ||
           [ $DFFREE -gt $(($BKFREE + $ALLOWANCE)) ] ; then
                error "df free($DFFREE) mismatch OST free($BKFREE)"
        fi
        if [ $DFAVAIL -lt $(($BKAVAIL - $ALLOWANCE)) ] ||
           [ $DFAVAIL -gt $(($BKAVAIL + $ALLOWANCE)) ] ; then
                error "df avail($DFAVAIL) mismatch OST avail($BKAVAIL)"
        fi
}
#run_test 79 "df report consistency check ======================="

function get_named_value()
{
    local tag=$1

    grep -w "$tag" | sed "s/^$tag  *\([0-9]*\)  *.*/\1/"
}

setup_test101bc() {
	test_mkdir $DIR/$tdir
	local ssize=$1
	local FILE_LENGTH=$2
	STRIPE_OFFSET=0

	local FILE_SIZE_MB=$((FILE_LENGTH / ssize))

	local list=$(comma_list $(osts_nodes))
	set_osd_param $list '' read_cache_enable 0
	set_osd_param $list '' writethrough_cache_enable 0

	trap cleanup_test101bc EXIT
	# prepare the read-ahead file
	$LFS setstripe -S $ssize -i $STRIPE_OFFSET -c $OSTCOUNT $DIR/$tfile

	dd if=/dev/zero of=$DIR/$tfile bs=$ssize \
				count=$FILE_SIZE_MB 2> /dev/null

}

cleanup_test101bc() {
	trap 0
	rm -rf $DIR/$tdir
	rm -f $DIR/$tfile

	local list=$(comma_list $(osts_nodes))
	set_osd_param $list '' read_cache_enable 1
	set_osd_param $list '' writethrough_cache_enable 1
}

calc_total() {
	awk 'BEGIN{total=0}; {total+=$1}; END{print total}'
}

test_102i() { # bug 17038
	[ -z "$(which getfattr 2>/dev/null)" ] &&
		skip "could not find getfattr"

	touch $DIR/$tfile
	ln -s $DIR/$tfile $DIR/${tfile}link
	getfattr -n trusted.lov $DIR/$tfile ||
		error "lgetxattr on $DIR/$tfile failed"
	getfattr -h -n trusted.lov $DIR/${tfile}link 2>&1 |
		grep -i "no such attr" ||
		error "error for lgetxattr on $DIR/${tfile}link is not ENODATA"
	rm -f $DIR/$tfile $DIR/${tfile}link
}
run_test 102i "lgetxattr test on symbolic link ============"

test_102l() {
	[ -z "$(which getfattr 2>/dev/null)" ] &&
		skip "could not find getfattr"

	# LU-532 trusted. xattr is invisible to non-root
	local testfile=$DIR/$tfile

	touch $testfile

	echo "listxattr as user..."
	chown $RUNAS_ID $testfile
	$RUNAS getfattr -d -m '.*' $testfile 2>&1 |
	    grep -q "trusted" &&
		error "$testfile trusted xattrs are user visible"

	return 0;
}
run_test 102l "listxattr size test =================================="

test_102m() { # LU-3403 llite: error of listxattr when buffer is small
	local path=$DIR/$tfile
	touch $path

	listxattr_size_check $path || error "listattr_size_check $path failed"
}
run_test 102m "Ensure listxattr fails on small bufffer ========"

getxattr() { # getxattr path name
	# Return the base64 encoding of the value of xattr name on path.
	local path=$1
	local name=$2

	# # getfattr --absolute-names --encoding=base64 --name=trusted.lov $path
	# file: $path
	# trusted.lov=0s0AvRCwEAAAAGAAAAAAAAAAAEAAACAAAAAAAQAAEAA...AAAAAAAAA=
	#
	# We print just 0s0AvRCwEAAAAGAAAAAAAAAAAEAAACAAAAAAAQAAEAA...AAAAAAAAA=

	getfattr --absolute-names --encoding=base64 --name=$name $path |
		awk -F= -v name=$name '$1 == name {
			print substr($0, index($0, "=") + 1);
	}'
}

test_102n() { # LU-4101 mdt: protect internal xattrs
	[ -z "$(which setfattr 2>/dev/null)" ] &&
		skip "could not find setfattr"

	local file0=$DIR/$tfile.0
	local file1=$DIR/$tfile.1
	local xattr0=$TMP/$tfile.0
	local xattr1=$TMP/$tfile.1
	local namelist="lov lma lmv link fid version som hsm"
	local name
	local value

	rm -rf $file0 $file1 $xattr0 $xattr1
	touch $file0 $file1

	# Get 'before' xattrs of $file1.
	getfattr --absolute-names --dump --match=- $file1 > $xattr0

	for name in $namelist; do
		# Try to copy xattr from $file0 to $file1.
		value=$(getxattr $file0 trusted.$name 2> /dev/null)

		setfattr --name=trusted.$name --value="$value" $file1 ||
			error "setxattr 'trusted.$name' failed"

		# Try to set a garbage xattr.
		value=0sVGhlIHF1aWNrIGJyb3duIGZveCBqdW1wcyBvdmVyIGl0c2VsZi4=

		if [[ x$name == "xlov" ]]; then
			setfattr --name=trusted.lov --value="$value" $file1 &&
			error "setxattr invalid 'trusted.lov' success"
		else
			setfattr --name=trusted.$name --value="$value" $file1 ||
				error "setxattr invalid 'trusted.$name' failed"
		fi

		# Try to remove the xattr from $file1. We don't care if this
		# appears to succeed or fail, we just don't want there to be
		# any changes or crashes.
		setfattr --remove=$trusted.$name $file1 2> /dev/null
	done

	# Get 'after' xattrs of file1.
	getfattr --absolute-names --dump --match=- $file1 > $xattr1

	if ! diff $xattr0 $xattr1; then
		error "before and after xattrs of '$file1' differ"
	fi

	rm -rf $file0 $file1 $xattr0 $xattr1

	return 0
}
run_test 102n "silently ignore setxattr on internal trusted xattrs"

test_102p() { # LU-4703 setxattr did not check ownership
	local testfile=$DIR/$tfile

	touch $testfile

	echo "setfacl as user..."
	$RUNAS setfacl -m "u:$RUNAS_ID:rwx" $testfile
	[ $? -ne 0 ] || error "setfacl by $RUNAS_ID was allowed on $testfile"

	echo "setfattr as user..."
	setfacl -m "u:$RUNAS_ID:---" $testfile
	$RUNAS setfattr -x system.posix_acl_access $testfile
	[ $? -ne 0 ] || error "setfattr by $RUNAS_ID was allowed on $testfile"
}
run_test 102p "check setxattr(2) correctly fails without permission"

test_102q() {
	orphan_linkea_check $DIR/$tfile || error "orphan_linkea_check"
}
run_test 102q "flistxattr should not return trusted.link EAs for orphans"

test_102r() {
	touch $DIR/$tfile || error "touch"
	setfattr -n user.$(basename $tfile) $DIR/$tfile || error "setfattr"
	getfattr -n user.$(basename $tfile) $DIR/$tfile || error "getfattr"
	rm $DIR/$tfile || error "rm"

	#normal directory
	mkdir -p $DIR/$tdir || error "mkdir"
	setfattr -n user.$(basename $tdir) $DIR/$tdir || error "setfattr dir"
	getfattr -n user.$(basename $tdir) $DIR/$tdir || error "getfattr dir"
	setfattr -x user.$(basename $tdir) $DIR/$tdir ||
		error "$testfile error deleting user.author1"
	getfattr -d -m user.$(basename $tdir) 2> /dev/null |
		grep "user.$(basename $tdir)" &&
		error "$tdir did not delete user.$(basename $tdir)"
	rmdir $DIR/$tdir || error "rmdir"

	#striped directory
	test_mkdir $DIR/$tdir
	setfattr -n user.$(basename $tdir) $DIR/$tdir || error "setfattr dir"
	getfattr -n user.$(basename $tdir) $DIR/$tdir || error "getfattr dir"
	setfattr -x user.$(basename $tdir) $DIR/$tdir ||
		error "$testfile error deleting user.author1"
	getfattr -d -m user.$(basename $tdir) 2> /dev/null |
		grep "user.$(basename $tdir)" &&
		error "$tdir did not delete user.$(basename $tdir)"
	rmdir $DIR/$tdir || error "rm striped dir"
}
run_test 102r "set EAs with empty values"

run_acl_subtest()
{
    $YRFS/acl/run $yrfs/acl/$1.test
    return $?
}

test_103c() {
	mkdir -p $DIR/$tdir
	cp -rp $DIR/$tdir $DIR/$tdir.bak

	[ -n "$(getfattr -d -m. $DIR/$tdir | grep posix_acl_default)" ] &&
		error "$DIR/$tdir shouldn't contain default ACL"
	[ -n "$(getfattr -d -m. $DIR/$tdir.bak | grep posix_acl_default)" ] &&
		error "$DIR/$tdir.bak shouldn't contain default ACL"
	true
}
run_test 103c "'cp -rp' won't set empty acl"

#
# Verify $1 is within range of $2.
# Success when $1 is within range. That is, when $1 is >= 2% of $2 and
# $1 is <= 2% of $2. Else Fail.
#
value_in_range() {
	# Strip all units (M, G, T)
	actual=$(echo $1 | tr -d A-Z)
	expect=$(echo $2 | tr -d A-Z)

	expect_lo=$(($expect * 98 / 100)) # 2% below
	expect_hi=$(($expect * 102 / 100)) # 2% above

	# permit 2% drift above and below
	(( $actual >= $expect_lo && $actual <= $expect_hi ))
}

test_105a() {
	# doesn't work on 2.4 kernels
	touch $DIR/$tfile
	if $(flock_is_enabled); then
		flocks_test 1 on -f $DIR/$tfile || error "fail flock on"
	else
		flocks_test 1 off -f $DIR/$tfile || error "fail flock off"
	fi
	rm -f $DIR/$tfile
}
run_test 105a "flock when mounted without -o flock test ========"

test_105b() {
	touch $DIR/$tfile
	if $(flock_is_enabled); then
		flocks_test 1 on -c $DIR/$tfile || error "fail flock on"
	else
		flocks_test 1 off -c $DIR/$tfile || error "fail flock off"
	fi
	rm -f $DIR/$tfile
}
run_test 105b "fcntl when mounted without -o flock test ========"

test_105c() {
	touch $DIR/$tfile
	if $(flock_is_enabled); then
		flocks_test 1 on -l $DIR/$tfile || error "fail flock on"
	else
		flocks_test 1 off -l $DIR/$tfile || error "fail flock off"
	fi
	rm -f $DIR/$tfile
}
run_test 105c "lockf when mounted without -o flock test"

test_105e() { # bug 22660 && 22040
	flock_is_enabled || skip_env "mount w/o flock enabled"

	touch $DIR/$tfile
	flocks_test 3 $DIR/$tfile
}
run_test 105e "Two conflicting flocks from same process"

test_106() { #bug 10921
	test_mkdir $DIR/$tdir
	$DIR/$tdir && error "exec $DIR/$tdir succeeded"
	chmod 777 $DIR/$tdir || error "chmod $DIR/$tdir failed"
}
run_test 106 "attempt exec of dir followed by chown of that dir"

test_107() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	CDIR=`pwd`
	local file=core

	cd $DIR
	rm -f $file

        local save_pattern=$(sysctl -n kernel.core_pattern)
        local save_uses_pid=$(sysctl -n kernel.core_uses_pid)
        sysctl -w kernel.core_pattern=$file
        sysctl -w kernel.core_uses_pid=0

        ulimit -c unlimited
        sleep 60 &
        SLEEPPID=$!

        sleep 1

        kill -s 11 $SLEEPPID
        wait $SLEEPPID
        if [ -e $file ]; then
                size=`stat -c%s $file`
                [ $size -eq 0 ] && error "Fail to create core file $file"
        else
                error "Fail to create core file $file"
        fi
        rm -f $file
        sysctl -w kernel.core_pattern=$save_pattern
        sysctl -w kernel.core_uses_pid=$save_uses_pid
        cd $CDIR
}
run_test 107 "Coredump on SIG"

test_110() {
	test_mkdir $DIR/$tdir
	test_mkdir $DIR/$tdir/$(str_repeat 'a' 255)
	$LFS mkdir -c $MDSCOUNT $DIR/$tdir/$(str_repeat 'b' 256) &&
		error "mkdir with 256 char should fail, but did not"
	touch $DIR/$tdir/$(str_repeat 'x' 255) ||
		error "create with 255 char failed"
	touch $DIR/$tdir/$(str_repeat 'y' 256) &&
		error "create with 256 char should fail, but did not"

	ls -l $DIR/$tdir
	rm -rf $DIR/$tdir
}
#run_test 110 "filename length checking"

NO_SLOW_RESENDCOUNT=4
export OLD_RESENDCOUNT=""
set_resend_count () {
	local PROC_RESENDCOUNT="osc.${FSNAME}-OST*-osc-*.resend_count"
	#OLD_RESENDCOUNT=$(lctl get_param -n $PROC_RESENDCOUNT | head -n1)
	#lctl set_param -n $PROC_RESENDCOUNT $1
	#echo resend_count is set to $(lctl get_param -n $PROC_RESENDCOUNT)
}

# for reduce test_118* time (b=14842)
[ "$SLOW" = "no" ] && set_resend_count $NO_SLOW_RESENDCOUNT

test_118l() # LU-646
{
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	test_mkdir $DIR/$tdir
	$MULTIOP $DIR/$tdir Dy || error "fsync dir failed"
	rm -rf $DIR/$tdir
}
run_test 118l "fsync dir"

test_119a() # bug 11737
{
        BSIZE=$((512 * 1024))
        directio write $DIR/$tfile 0 1 $BSIZE
        # We ask to read two blocks, which is more than a file size.
        # directio will indicate an error when requested and actual
        # sizes aren't equeal (a normal situation in this case) and
        # print actual read amount.
        NOB=`directio read $DIR/$tfile 0 2 $BSIZE | awk '/error/ {print $6}'`
        if [ "$NOB" != "$BSIZE" ]; then
                error "read $NOB bytes instead of $BSIZE"
        fi
        rm -f $DIR/$tfile
}
run_test 119a "Short directIO read must return actual read amount"

test_119b() # bug 11737
{
	[[ $OSTCOUNT -lt 2 ]] && skip_env "needs >= 2 OSTs"

	$LFS setstripe -c 2 $DIR/$tfile || error "setstripe failed"
	dd if=/dev/zero of=$DIR/$tfile bs=1M count=1 seek=1 || error "dd failed"
	sync
	$MULTIOP $DIR/$tfile oO_RDONLY:O_DIRECT:r$((2048 * 1024)) ||
		error "direct read failed"
	rm -f $DIR/$tfile
}
#run_test 119b "Sparse directIO read must return actual read amount"

test_119c() # bug 13099
{
        BSIZE=1048576
        directio write $DIR/$tfile 3 1 $BSIZE || error "direct write failed"
        directio readhole $DIR/$tfile 0 2 $BSIZE || error "reading hole failed"
        rm -f $DIR/$tfile
}
run_test 119c "Testing for direct read hitting hole"

test_123c() {
	[[ $MDSCOUNT -lt 2 ]] && skip_env "needs >= 2 MDTs"

	test_mkdir -i 0 -c 1 $DIR/$tdir.0
	test_mkdir -i 1 -c 1 $DIR/$tdir.1
	touch $DIR/$tdir.1/{1..3}
	mv $DIR/$tdir.1/{1..3} $DIR/$tdir.0

	remount_client $MOUNT

	$MULTIOP $DIR/$tdir.0 Q

	# let statahead to complete
	ls -l $DIR/$tdir.0 > /dev/null

	testid=$(echo $TESTNAME | tr '_' ' ')
	dmesg | tac | sed "/$testid/,$ d" | grep "Can not initialize inode" &&
		error "statahead warning" || true
}
#run_test 123c "Can not initialize inode warning on DNE statahead"

get_max_pool_limit()
{
	local limit=$($LCTL get_param \
		      -n ldlm.namespaces.*-MDT0000-mdc-*.pool.limit)
	local max=0
	for l in $limit; do
		if [[ $l -gt $max ]]; then
			max=$l
		fi
	done
	echo $max
}

test_128() { # bug 15212
	touch $DIR/$tfile
	$LFS 2>&1 <<-EOF | tee $TMP/$tfile.log
		find $DIR/$tfile
		find $DIR/$tfile
	EOF

	result=$(grep error $TMP/$tfile.log)
	rm -f $DIR/$tfile $TMP/$tfile.log
	[ -z "$result" ] ||
		error "consecutive find's under interactive lfs failed"
}
#run_test 128 "interactive lfs for 2 consecutive find's"

test_130f() {
	filefrag_op=$(filefrag -e 2>&1 | grep "invalid option")
	[ -n "$filefrag_op" ] && skip "filefrag does not support FIEMAP"

	local fm_file=$DIR/$tfile
	$MULTIOP $fm_file oO_RDWR:O_CREAT:O_LOV_DELAY_CREATE:T33554432c ||
		error "multiop create with lov_delay_create on $fm_file"

	filefrag -ves $fm_file || error "filefrag $fm_file failed"
	filefrag_extents=$(filefrag -vek $fm_file |
	awk '/extents? found/ { print $2 }')
	if [[ "$filefrag_extents" != "0" ]]; then
		error "$fm_file: filefrag_extents=$filefrag_extents != 0"
	fi

	rm -f $fm_file
}
run_test 130f "FIEMAP (unstriped file)"

set_dir_limits () {
	local mntdev
	local canondev
	local node

	local ldproc=/proc/fs/ldiskfs
	local facets=$(get_facets MDS)

	for facet in ${facets//,/ }; do
		canondev=$(ldiskfs_canon \
			   *.$(convert_facet2label $facet).mntdev $facet)
		do_facet $facet "test -e $ldproc/$canondev/max_dir_size" ||
			ldproc=/sys/fs/ldiskfs
		do_facet $facet "echo $1 >$ldproc/$canondev/max_dir_size"
		do_facet $facet "echo $2 >$ldproc/$canondev/warning_dir_size"
	done
}

check_mds_dmesg() {
	local facets=$(get_facets MDS)
	for facet in ${facets//,/ }; do
		do_facet $facet "dmesg | tail -3 | grep $1" && return 0
	done
	return 1
}

# Test for writev/readv
test_131a() {
	rwv -f $DIR/$tfile -w -n 3 524288 1048576 1572864 ||
		error "writev test failed"
	rwv -f $DIR/$tfile -r -v -n 2 1572864 1048576 ||
		error "readv failed"
	rm -f $DIR/$tfile
}
run_test 131a "test iov's crossing stripe boundary for writev/readv"

test_131b() {
	local fsize=$((524288 + 1048576 + 1572864))
	rwv -f $DIR/$tfile -w -a -n 3 524288 1048576 1572864 &&
		$CHECKSTAT -t file $DIR/$tfile -s $fsize ||
			error "append writev test failed"

	((fsize += 1572864 + 1048576))
	rwv -f $DIR/$tfile -w -a -n 2 1572864 1048576 &&
		$CHECKSTAT -t file $DIR/$tfile -s $fsize ||
			error "append writev test failed"
	rm -f $DIR/$tfile
}
run_test 131b "test append writev"

test_131d() {
	rwv -f $DIR/$tfile -w -n 1 1572864
	NOB=`rwv -f $DIR/$tfile -r -n 3 524288 524288 1048576 | awk '/error/ {print $6}'`
	if [ "$NOB" != 1572864 ]; then
		error "Short read filed: read $NOB bytes instead of 1572864"
	fi
	rm -f $DIR/$tfile
}
run_test 131d "test short read"

test_131e() {
	rwv -f $DIR/$tfile -w -s 1048576 -n 1 1048576
	rwv -f $DIR/$tfile -r -z -s 0 -n 1 524288 || \
	error "read hitting hole failed"
	rm -f $DIR/$tfile
}
run_test 131e "test read hitting hole"

order_2() {
	local value=$1
	local orig=$value
	local order=1

	while [ $value -ge 2 ]; do
		order=$((order*2))
		value=$((value/2))
	done

	if [ $orig -gt $order ]; then
		order=$((order*2))
	fi
	echo $order
}

size_in_KMGT() {
    local value=$1
    local size=('K' 'M' 'G' 'T');
    local i=0
    local size_string=$value

    while [ $value -ge 1024 ]; do
        if [ $i -gt 3 ]; then
            #T is the biggest unit we get here, if that is bigger,
            #just return XXXT
            size_string=${value}T
            break
        fi
        value=$((value >> 10))
        if [ $value -lt 1024 ]; then
            size_string=${value}${size[$i]}
            break
        fi
        i=$((i + 1))
    done

    echo $size_string
}

test_140() { #bug-17379
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	test_mkdir $DIR/$tdir
	cd $DIR/$tdir || error "Changing to $DIR/$tdir"
	cp $(which stat) . || error "Copying stat to $DIR/$tdir"

	# VFS limits max symlink depth to 5(4KSTACK) or 7(8KSTACK) or 8
	# For kernel > 3.5, bellow only tests consecutive symlink (MAX 40)
	local i=0
	while i=$((i + 1)); do
		test_mkdir $i
		cd $i || error "Changing to $i"
		ln -s ../stat stat || error "Creating stat symlink"
		# Read the symlink until ELOOP present,
		# not LBUGing the system is considered success,
		# we didn't overrun the stack.
		$OPENFILE -f O_RDONLY stat >/dev/null 2>&1; ret=$?
		if [ $ret -ne 0 ]; then
			if [ $ret -eq 40 ]; then
				break  # -ELOOP
			else
				error "Open stat symlink"
					return
			fi
		fi
	done
	i=$((i - 1))
	echo "The symlink depth = $i"
	[ $i -eq 5 ] || [ $i -eq 7 ] || [ $i -eq 8 ] || [ $i -eq 40 ] ||
		error "Invalid symlink depth"

	# Test recursive symlink
	ln -s symlink_self symlink_self
	$OPENFILE -f O_RDONLY symlink_self >/dev/null 2>&1; ret=$?
	echo "open symlink_self returns $ret"
	[ $ret -eq 40 ] || error "recursive symlink doesn't return -ELOOP"
}
run_test 140 "Check reasonable stack depth (shouldn't LBUG) ===="

test_150a() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	local TF="$TMP/$tfile"

	rm -f $DIR/$tfile
	dd if=/dev/urandom of=$TF bs=6096 count=1 || error "dd failed"
	cp $TF $DIR/$tfile
	
	cmp $TF $DIR/$tfile || error "$TMP/$tfile $DIR/$tfile differ"
	yrstopall || error "yrstopall failed"
	yrsetupall || error "yrsetupall failed"
	df -P $MOUNT
	cmp $TF $DIR/$tfile || error "$TF $DIR/$tfile differ (remount)"

	$TRUNCATE $TF 6000
	$TRUNCATE $DIR/$tfile 6000
	cmp $TF $DIR/$tfile || error "$TF $DIR/$tfile differ (truncate1)"

	echo "12345" >>$TF
	echo "12345" >>$DIR/$tfile
	cmp $TF $DIR/$tfile || error "$TF $DIR/$tfile differ (append1)"

	echo "12345" >>$TF
	echo "12345" >>$DIR/$tfile
	cmp $TF $DIR/$tfile || error "$TF $DIR/$tfile differ (append2)"

	rm -f ${TF}
}
run_test 150a "truncate/append tests"

test_153() {
	$MULTIOP $DIR/$tfile Ow4096Ycu || error "multiop failed"
}
run_test 153 "test if fdatasync does not crash ======================="

test_154e()
{
	if ls -a $MOUNT | grep -q '^\.yrfs$'; then
		error ".yrfs returned by readdir"
	fi
}
run_test 154e ".yrfs is not returned by readdir"

test_165f() {
	local trace="/tmp/${tfile}.trace"
	local rc
	local count

	setup_165
	do_facet ost1 timeout 60 ofd_access_log_reader \
		--exit-on-close --debug=- --trace=- > "${trace}" &
	sleep 5
	stop ost1

	wait
	rc=$?

	if ((rc != 0)); then
		error_noexit "ofd_access_log_reader exited with rc = '${rc}'"
		cat "${trace}"
		exit 1
	fi
}
#run_test 165f "ofd_access_log_reader --exit-on-close works"

test_169() {
	# do directio so as not to populate the page cache
	log "creating a 10 Mb file"
	$MULTIOP $DIR/$tfile oO_CREAT:O_DIRECT:O_RDWR:w$((10*1048576))c ||
		error "multiop failed while creating a file"
	log "starting reads"
	dd if=$DIR/$tfile of=/dev/null bs=4096 &
	log "truncating the file"
	$MULTIOP $DIR/$tfile oO_TRUNC:c ||
		error "multiop failed while truncating the file"
	log "killing dd"
	kill %+ || true # reads might have finished
	echo "wait until dd is finished"
	wait
	log "removing the temporary file"
	rm -rf $DIR/$tfile || error "tmp file removal failed"
}
run_test 169 "parallel read and truncate should not deadlock"

test_181() { # bug 22177
	test_mkdir $DIR/$tdir
	# create enough files to index the directory
	createmany -o $DIR/$tdir/foobar 4000
	# print attributes for debug purpose
	lsattr -d .
	# open dir
	multiop_bg_pause $DIR/$tdir D_Sc || return 1
	MULTIPID=$!
	# remove the files & current working dir
	unlinkmany $DIR/$tdir/foobar 4000
	rmdir $DIR/$tdir
	kill -USR1 $MULTIPID
	wait $MULTIPID
	stat $DIR/$tdir && error "open-unlinked dir was not removed!"
	return 0
}
run_test 181 "Test open-unlinked dir ========================"

# Figure out which job scheduler is being used, if any,
# or use a fake one
if [ -n "$SLURM_JOB_ID" ]; then # SLURM
	JOBENV=SLURM_JOB_ID
elif [ -n "$LSB_JOBID" ]; then # Load Sharing Facility
	JOBENV=LSB_JOBID
elif [ -n "$PBS_JOBID" ]; then # PBS/Maui/Moab
	JOBENV=PBS_JOBID
elif [ -n "$LOADL_STEPID" ]; then # LoadLeveller
	JOBENV=LOADL_STEP_ID
elif [ -n "$JOB_ID" ]; then # Sun Grid Engine
	JOBENV=JOB_ID
else
	JOBENV=FAKE_JOBID
fi
YRFS_JOBID_SIZE=31 # plus NUL terminator

jobstats_set() {
	local new_jobenv=$1

	set_persistent_param_and_check client "jobid_var" \
		"$FSNAME.sys.jobid_var" $new_jobenv
}
test_212() {
	size=`date +%s`
	size=$((size % 8192 + 1))
	dd if=/dev/urandom of=$DIR/f212 bs=1k count=$size
	sendfile $DIR/f212 $DIR/f212.xyz || error "sendfile wrong"
	rm -f $DIR/f212 $DIR/f212.xyz
}
run_test 212 "Sendfile test ============================================"

test_214() { # for bug 20133
	mkdir -p $DIR/$tdir/d214c || error "mkdir $DIR/$tdir/d214c failed"
	for (( i=0; i < 340; i++ )) ; do
		touch $DIR/$tdir/d214c/a$i
	done

	ls -l $DIR/$tdir || error "ls -l $DIR/d214p failed"
	mv $DIR/$tdir/d214c $DIR/ || error "mv $DIR/d214p/d214c $DIR/ failed"
	ls $DIR/d214c || error "ls $DIR/d214c failed"
	rm -rf $DIR/$tdir || error "rm -rf $DIR/d214* failed"
	rm -rf $DIR/d214* || error "rm -rf $DIR/d214* failed"
}
run_test 214 "hash-indexed directory test - bug 20133"

# LU-1299 Executing or running ldd on a truncated executable does not
# cause an out-of-memory condition.
test_227() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"
	[ -z "$(which ldd)" ] && skip_env "should have ldd tool"

	dd if=$(which date) of=$MOUNT/date bs=1k count=1
	chmod +x $MOUNT/date

	$MOUNT/date > /dev/null
	ldd $MOUNT/date > /dev/null
	rm -f $MOUNT/date
}
run_test 227 "running truncated executable does not cause OOM"

test_231b() {
	mkdir -p $DIR/$tdir
	local i
	for i in {0..1023}; do
		dd if=/dev/zero of=$DIR/$tdir/$tfile conv=notrunc \
			seek=$((2 * i)) bs=4096 count=1 &>/dev/null ||
			error "dd of=$DIR/$tdir/$tfile seek=$((2 * i)) failed"
	done
	sync
}
run_test 231b "must not assert on fully utilized OST request buffer"

test_235() {
	flock_deadlock $DIR/$tfile
	local RC=$?
	case $RC in
		0)
		;;
		124) error "process hangs on a deadlock"
		;;
		*) error "error executing flock_deadlock $DIR/$tfile"
		;;
	esac
}
run_test 235 "LU-1715: flock deadlock detection does not work properly"

test_241_bio() {
	local count=$1
	local bsize=$2

	for LOOP in $(seq $count); do
		dd if=$DIR/$tfile of=/dev/null bs=$bsize count=1 2>/dev/null || true
	done
}

test_241_dio() {
	local count=$1
	local bsize=$2

	for LOOP in $(seq $1); do
		dd if=$DIR/$tfile of=/dev/null bs=$bsize count=1 iflag=direct \
			2>/dev/null
	done
}

test_241a() { # was test_241
	local bsize=$PAGE_SIZE

	(( bsize < 40960 )) && bsize=40960
	dd if=/dev/zero of=$DIR/$tfile count=1 bs=$bsize
	ls -la $DIR/$tfile
	test_241_bio 1000 $bsize &
	PID=$!
	test_241_dio 1000 $bsize
	wait $PID
}
run_test 241a "bio vs dio"

test_241b() {
	local bsize=$PAGE_SIZE

	(( bsize < 40960 )) && bsize=40960
	dd if=/dev/zero of=$DIR/$tfile count=1 bs=$bsize
	ls -la $DIR/$tfile
	test_241_dio 1000 $bsize &
	PID=$!
	test_241_dio 1000 $bsize
	wait $PID
}
run_test 241b "dio vs dio"

test_243()
{
	test_mkdir $DIR/$tdir
	group_lock_test -d $DIR/$tdir || error "A group lock test failed"
}
#run_test 243 "various group lock tests"

test_244a()
{
	test_mkdir $DIR/$tdir
	dd if=/dev/zero of=$DIR/$tdir/$tfile bs=1M count=35
	sendfile_grouplock $DIR/$tdir/$tfile || \
		error "sendfile+grouplock failed"
	rm -rf $DIR/$tdir
}
#run_test 244a "sendfile with group lock tests"

percent() {
	bc <<<"scale=2; ($1 - $2) * 100 / $2"
}

# run a random read IO workload
# usage: random_read_iops <filename> <filesize> <iosize>
random_read_iops() {
	local file=$1
	local fsize=$2
	local iosize=${3:-4096}

	$READS -f $file -s $fsize -b $iosize -n $((fsize / iosize)) -t 60 |
		sed -e '/^$/d' -e 's#.*s, ##' -e 's#MB/s##'
}

drop_file_oss_cache() {
	local file="$1"
	local nodes="$2"

	$LFS ladvise -a dontneed $file 2>/dev/null ||
		do_nodes $nodes "echo 3 > /proc/sys/vm/drop_caches"
}

facet_meminfo() {
	local facet=$1
	local info=$2

	do_facet $facet "cat /proc/meminfo | grep ^${info}:" | awk '{print $2}'
}

test_260() {
#define OBD_FAIL_MDC_CLOSE               0x806
	touch $DIR/$tfile
}
run_test 260 "Check mdc_close fail"

zfs_oid_to_objid()
{
	local ost=$1
	local objid=$2

	local vdevdir=$(dirname $(facet_vdevice $ost))
	local cmd="$ZDB -e -p $vdevdir -ddddd $(facet_device $ost)"
	local zfs_zapid=$(do_facet $ost $cmd |
			  grep -w "/O/0/d$((objid%32))" -C 5 |
			  awk '/Object/{getline; print $1}')
	local zfs_objid=$(do_facet $ost $cmd $zfs_zapid |
			  awk "/$objid = /"'{printf $3}')

	echo $zfs_objid
}

zfs_object_blksz() {
	local ost=$1
	local objid=$2

	local vdevdir=$(dirname $(facet_vdevice $ost))
	local cmd="$ZDB -e -p $vdevdir -dddd $(facet_device $ost)"
	local blksz=$(do_facet $ost $cmd $objid |
		      awk '/dblk/{getline; printf $4}')

	case "${blksz: -1}" in
		k|K) blksz=$((${blksz:0:$((${#blksz} - 1))}*1024)) ;;
		m|M) blksz=$((${blksz:0:$((${#blksz} - 1))}*1024*1024)) ;;
		*) ;;
	esac

	echo $blksz
}

test_315() { # LU-618
	[ -f /proc/$$/io ] || skip_env "no IO accounting in kernel"

	local file=$DIR/$tfile
	rm -f $file

	$MULTIOP $file oO_CREAT:O_DIRECT:O_RDWR:w4063232c ||
		error "multiop file write failed"
	$MULTIOP $file oO_RDONLY:r4063232_c &
	PID=$!

	sleep 2

	local rbytes=$(awk '/read_bytes/ { print $2 }' /proc/$PID/io)
	kill -USR1 $PID

	[ $rbytes -gt 4000000 ] || error "read is not accounted ($rbytes)"
	rm -f $file
}
run_test 315 "read should be accounted"

test_398d() { #  LU-13846
	which aiocp || skip_env "no aiocp installed"
	local aio_file=$DIR/$tfile.aio

	$LFS setstripe -c -1 -S 1M $DIR/$tfile $aio_file

	dd if=/dev/urandom of=$DIR/$tfile bs=1M count=64
	aiocp -a $PAGE_SIZE -b 64M -s 64M -f O_DIRECT $DIR/$tfile $aio_file
	stack_trap "rm -f $DIR/$tfile $aio_file"

	diff $DIR/$tfile $aio_file || error "file diff after aiocp"

	# make sure we don't crash and fail properly
	aiocp -a 512 -b 64M -s 64M -f O_DIRECT $DIR/$tfile $aio_file &&
		error "aio not aligned with PAGE SIZE should fail"

	rm -f $DIR/$tfile $aio_file
}
run_test 398d "run aiocp to verify block size > stripe size"

test_398e() {
	dd if=/dev/zero of=$DIR/$tfile bs=1234 count=1
	touch $DIR/$tfile.new
	dd if=$DIR/$tfile of=$DIR/$tfile.new bs=1M count=1 oflag=direct
}
run_test 398e "O_Direct open cleared by fcntl doesn't cause hang"

# Parallel submission of DIO should not cause problems for append, but it's
# important to verify.
test_398n() { #  LU-13798
	$LFS setstripe -C 2 -S 1M $DIR/$tfile

	dd if=/dev/urandom of=$DIR/$tfile bs=8M count=8 ||
		error "dd to create source file failed"
	stack_trap "rm -f $DIR/$tfile"

	dd if=$DIR/$tfile of=$DIR/$tfile.1 bs=8M count=8 oflag=direct oflag=append ||
		error "parallel dio write with failure on second stripe succeeded"
	stack_trap "rm -f $DIR/$tfile $DIR/$tfile.1"
	diff $DIR/$tfile $DIR/$tfile.1
	[[ $? == 0 ]] || error "data incorrect after append"

}
run_test 398n "test append with parallel DIO"

test_405() {
	[ -n "$FILESET" ] && skip "Not functional for FILESET set"
	[ $MDS1_VERSION -lt $(version_code 2.6.92) ] ||
		[ $CLIENT_VERSION -lt $(version_code 2.6.99) ] &&
			skip "Layout swap lock is not supported"

	check_swap_layouts_support
	check_swap_layout_no_dom $DIR

	test_mkdir $DIR/$tdir
	swap_lock_test -d $DIR/$tdir ||
		error "One layout swap locked test failed"
}
#run_test 405 "Various layout swap lock tests"

cleanup_test411_cgroup() {
	trap 0
	rmdir "$1"
}

test_413z() {
	local pids=""
	local subdir
	local pid

	for subdir in $(\ls -1 -d $DIR/d413*-fillmdt/*); do
		unlinkmany $subdir/f. 100 &
		pids="$pids $!"
	done

	for pid in $pids; do
		wait $pid
	done
}
run_test 413z "413 test cleanup"

test_415() {
	[ $PARALLEL == "yes" ] && skip "skip parallel run"

	# LU-11102
	local total
	local setattr_pid
	local start_time
	local end_time
	local duration

	total=500
	# this test may be slow on ZFS
	[ "$mds1_FSTYPE" == "zfs" ] && total=100

	# though this test is designed for striped directory, let's test normal
	# directory too since lock is always saved as CoS lock.
	test_mkdir $DIR/$tdir || error "mkdir $tdir"
	createmany -o $DIR/$tdir/$tfile. $total || error "createmany"

	(
		while true; do
			touch $DIR/$tdir
		done
	) &
	setattr_pid=$!

	start_time=$(date +%s)
	for i in $(seq $total); do
		mrename $DIR/$tdir/$tfile.$i $DIR/$tdir/$tfile-new.$i \
			> /dev/null
	done
	end_time=$(date +%s)
	duration=$((end_time - start_time))

	kill -9 $setattr_pid

	echo "rename $total files took $duration sec"
	[ $duration -lt 100 ] || error "rename took $duration sec"
}
run_test 415 "lock revoke is not missing"

test_420()
{
	local SAVE_UMASK=$(umask)
	local dir=$DIR/$tdir
	local uname=$(getent passwd $RUNAS_ID | cut -d: -f1)

	mkdir -p $dir
	umask 0000
	mkdir -m03777 $dir/testdir
	ls -dn $dir/testdir
	# Need to remove trailing '.' when SELinux is enabled
	local dirperms=$(ls -dn $dir/testdir |
			 awk '{ sub(/\.$/, "", $1); print $1}')
	[ $dirperms == "drwxrwsrwt" ] ||
		error "incorrect perms on $dir/testdir"

	su - $uname -c "PATH=$YRFS:\$PATH; \
		openfile -f O_RDONLY:O_CREAT -m 02755 $dir/testdir/testfile"
	ls -n $dir/testdir/testfile
	local fileperms=$(ls -n $dir/testdir/testfile |
			  awk '{ sub(/\.$/, "", $1); print $1}')
	[ $fileperms == "-rwxr-xr-x" ] ||
		error "incorrect perms on $dir/testdir/testfile"

	umask $SAVE_UMASK
}
run_test 420 "clear SGID bit on non-directories for non-members"

stat_test() {
    df -h $MOUNT &
    df -h $MOUNT &
    df -h $MOUNT &
    df -h $MOUNT &
    df -h $MOUNT &
    df -h $MOUNT &
}

test_423() {
    local _stats
    # ensure statfs cache is expired
    sleep 2;

    _stats=$(stat_test | grep $MOUNT | sort -u | wc -l)
    [[ ${_stats} -ne 1 ]] && error "statfs wrong"

    return 0
}
run_test 423 "statfs should return a right data"

test_426() {
	splice-test -r $DIR/$tfile
	splice-test -rd $DIR/$tfile
	splice-test $DIR/$tfile
	splice-test -d $DIR/$tfile
}
#run_test 426 "splice test on yrfs"

lseek_test_430() {
	local offset
	local file=$1

	# data at [200K, 400K)
	dd if=/dev/urandom of=$file bs=256K count=1 seek=1 ||
		error "256K->512K dd fails"
	# data at [2M, 3M)
	dd if=/dev/urandom of=$file bs=1M count=1 seek=2 ||
		error "2M->3M dd fails"
	# data at [4M, 5M)
	dd if=/dev/urandom of=$file bs=1M count=1 seek=4 ||
		error "4M->5M dd fails"
	echo "Data at 256K...512K, 2M...3M and 4M...5M"
	# start at first component hole #1
	printf "Seeking hole from 1000 ... "
	offset=$(lseek_test -l 1000 $file)
	echo $offset
	[[ $offset == 1000 ]] || error "offset $offset != 1000"
	printf "Seeking data from 1000 ... "
	offset=$(lseek_test -d 1000 $file)
	echo $offset
	[[ $offset == 262144 ]] || error "offset $offset != 262144"

	# start at first component data block
	printf "Seeking hole from 300000 ... "
	offset=$(lseek_test -l 300000 $file)
	echo $offset
	[[ $offset == 524288 ]] || error "offset $offset != 524288"
	printf "Seeking data from 300000 ... "
	offset=$(lseek_test -d 300000 $file)
	echo $offset
	[[ $offset == 300000 ]] || error "offset $offset != 300000"

	# start at the first component but beyond end of object size
	printf "Seeking hole from 1000000 ... "
	offset=$(lseek_test -l 1000000 $file)
	echo $offset
	[[ $offset == 1000000 ]] || error "offset $offset != 1000000"
	printf "Seeking data from 1000000 ... "
	offset=$(lseek_test -d 1000000 $file)
	echo $offset
	[[ $offset == 2097152 ]] || error "offset $offset != 2097152"

	# start at second component stripe 2 (empty file)
	printf "Seeking hole from 1500000 ... "
	offset=$(lseek_test -l 1500000 $file)
	echo $offset
	[[ $offset == 1500000 ]] || error "offset $offset != 1500000"
	printf "Seeking data from 1500000 ... "
	offset=$(lseek_test -d 1500000 $file)
	echo $offset
	[[ $offset == 2097152 ]] || error "offset $offset != 2097152"

	# start at second component stripe 1 (all data)
	printf "Seeking hole from 3000000 ... "
	offset=$(lseek_test -l 3000000 $file)
	echo $offset
	[[ $offset == 3145728 ]] || error "offset $offset != 3145728"
	printf "Seeking data from 3000000 ... "
	offset=$(lseek_test -d 3000000 $file)
	echo $offset
	[[ $offset == 3000000 ]] || error "offset $offset != 3000000"

	dd if=/dev/urandom of=$file bs=640K count=1 seek=1 ||
		error "2nd dd fails"
	echo "Add data block at 640K...1280K"

	# start at before new data block, in hole
	printf "Seeking hole from 600000 ... "
	offset=$(lseek_test -l 600000 $file)
	echo $offset
	[[ $offset == 600000 ]] || error "offset $offset != 600000"
	printf "Seeking data from 600000 ... "
	offset=$(lseek_test -d 600000 $file)
	echo $offset
	[[ $offset == 655360 ]] || error "offset $offset != 655360"

	# start at the first component new data block
	printf "Seeking hole from 1000000 ... "
	offset=$(lseek_test -l 1000000 $file)
	echo $offset
	[[ $offset == 1310720 ]] || error "offset $offset != 1310720"
	printf "Seeking data from 1000000 ... "
	offset=$(lseek_test -d 1000000 $file)
	echo $offset
	[[ $offset == 1000000 ]] || error "offset $offset != 1000000"

	# start at second component stripe 2, new data
	printf "Seeking hole from 1200000 ... "
	offset=$(lseek_test -l 1200000 $file)
	echo $offset
	[[ $offset == 1310720 ]] || error "offset $offset != 1310720"
	printf "Seeking data from 1200000 ... "
	offset=$(lseek_test -d 1200000 $file)
	echo $offset
	[[ $offset == 1200000 ]] || error "offset $offset != 1200000"

	# start beyond file end
	printf "Using offset > filesize ... "
	lseek_test -l 4000000 $file && error "lseek should fail"
	printf "Using offset > filesize ... "
	lseek_test -d 4000000 $file && error "lseek should fail"

	printf "Done\n\n"
}

prep_801() {
	[[ $MDS1_VERSION -lt $(version_code 2.9.55) ]] ||
	[[ $OST1_VERSION -lt $(version_code 2.9.55) ]] &&
		skip "Need server version at least 2.9.55"

	start_full_debug_logging
}

post_801() {
	stop_full_debug_logging
}

saved_MGS_MOUNT_OPTS=$MGS_MOUNT_OPTS
saved_MDS_MOUNT_OPTS=$MDS_MOUNT_OPTS
saved_OST_MOUNT_OPTS=$OST_MOUNT_OPTS
saved_MOUNT_OPTS=$MOUNT_OPTS

cleanup_802a() {
	trap 0

	stopall
	MGS_MOUNT_OPTS=$saved_MGS_MOUNT_OPTS
	MDS_MOUNT_OPTS=$saved_MDS_MOUNT_OPTS
	OST_MOUNT_OPTS=$saved_OST_MOUNT_OPTS
	MOUNT_OPTS=$saved_MOUNT_OPTS
	setupall
}

cleanup_805() {
	do_facet $SINGLEMDS zfs set quota=$old $fsset
	unlinkmany $DIR/$tdir/f- 1000000
	trap 0
}

test_814()
{
	dd of=$DIR/$tfile seek=128 bs=1k < /dev/null
	echo -n y >> $DIR/$tfile
	cp --sparse=always $DIR/$tfile $DIR/${tfile}.cp || error "copy failed"
	diff $DIR/$tfile $DIR/${tfile}.cp || error "files should be same"
}
run_test 814 "sparse cp works as expected (LU-12361)"

test_815()
{
	writeme -b 100 $DIR/$tfile || error "write 100 bytes failed"
	writeme -b 0 $DIR/$tfile || error "write 0 byte failed"
}
run_test 815 "zero byte tiny write doesn't hang (LU-12382)"

complete $SECONDS
[ -f $EXT2_DEV ] && rm $EXT2_DEV || true
check_and_cleanup_yrfs
exit_status
