#!/bin/bash
#
# usage: acceptance-small.sh [test list]
#	if no tests are specified, they are taken from test-groups/regression
#	if {TEST_NAME}=no is set, that test script is skipped
DEFAULT_SUITES="${@:-$ACC_SM_ONLY}"
: ${YRFSTEST:=$(cd $(dirname $0); echo $PWD)}

DEFAULT_SUITES="${DEFAULT_SUITES:-$(cat $YRFSTEST/test-groups/regression)}"
for SUB in $DEFAULT_SUITES; do
	ENV=$(echo $SUB | tr "[:lower:]-" "[:upper:]_")
	[ "$(eval echo \$$ENV)" = "no" ] && continue
	SUITES="$SUITES $SUB"
done
#sh auster -r -R -v -f ${NAME:-yrfs} $SUITES 
sh auster -r -R -v -f ${NAME:-yrfs} $SUITES --except "24d 24h 24n 28 31b 33a
39o 48b 48c 48d 52a 52b 54b 54c 54e 102i 102m 102n 102r 130f 420 39a" 
